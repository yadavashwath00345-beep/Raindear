export type Lang = "en" | "hi";

export const translations = {
  en: {
    // Nav
    explore:    "Explore",
    nature:     "Nature",
    facts:      "Facts",
    quotes:     "Quotes",
    games:      "Games",
    shayari:    "Shayari",
    music:      "Music",
    // Header
    tagline:    "Your World",
    install:    "Install",
    // Search
    searchPlaceholder: "Search shayari, quotes, facts...",
    searchTitle:       "Search",
    noResults:         "No results found",
    noResultsHint:     "Try different keywords",
    resultsFor:        "Results for",
    // Explore
    exploreHeroTitle:  "Explore Raindear",
    exploreHeroSub:    "Curated videos — shayari, horror, fashion, style & news",
    tapHint:           "Tap any video to start watching",
    // Nature
    natureHeroTitle:   "Nature Escape",
    natureHeroSub:     "Forests, oceans, mountains & wildlife — breathe and unwind",
    // Facts
    factsHeroTitle:    "Did You Know?",
    factsHeroSub:      "120+ mind-blowing facts across 10 categories",
    // Quotes
    quotesHeroTitle:   "Quote of the Day",
    quotesHeroSub:     "quotes across 10 moods — a new one every day",
    todayQuote:        "Today's Quote",
    dailyPick:         "Daily Pick",
    browseByMood:      "Browse by mood:",
    moreQuotes:        "More Quotes",
    total:             "total",
    // Games
    gamesHeroTitle:    "Games Shelf",
    gamesHeroSub:      "games planned across 10 categories",
    comingSoon:        "Coming Soon",
    // Shayari
    shayariHeroTitle:  "Shayari",
    shayariHeroSub:    "Dil ki baat, lafzon mein — tap Copy to share",
    // Music
    musicHeroTitle:    "Music Lounge",
    musicHeroSub:      "Lo-fi, Chill, Sufi & Desi beats — your vibe, your soundtrack",
    nowPlaying:        "Now Playing",
    selectTrack:       "Select a track below to start playing",
    tracks:            "Tracks",
    available:         "available",
    stop:              "Stop",
    // Common
    copy:              "Copy",
    copied:            "Copied",
    share:             "Share",
    like:              "Like",
    liked:             "Liked",
    categories:        "Categories",
    videos:            "Videos",
    hours:             "Hours",
    source:            "Source",
    language:          "EN",
  },
  hi: {
    // Nav
    explore:    "खोजें",
    nature:     "प्रकृति",
    facts:      "तथ्य",
    quotes:     "विचार",
    games:      "खेल",
    shayari:    "शायरी",
    music:      "संगीत",
    // Header
    tagline:    "आपकी दुनिया",
    install:    "इंस्टॉल",
    // Search
    searchPlaceholder: "शायरी, विचार, तथ्य खोजें...",
    searchTitle:       "खोज",
    noResults:         "कोई परिणाम नहीं मिला",
    noResultsHint:     "अलग शब्द आज़माएं",
    resultsFor:        "परिणाम",
    // Explore
    exploreHeroTitle:  "रेनडियर खोजें",
    exploreHeroSub:    "क्यूरेटेड वीडियो — शायरी, हॉरर, फ़ैशन, स्टाइल और न्यूज़",
    tapHint:           "कोई भी वीडियो टैप करें",
    // Nature
    natureHeroTitle:   "प्रकृति की गोद में",
    natureHeroSub:     "जंगल, समुद्र, पहाड़ और वन्यजीव — सुकून पाएं",
    // Facts
    factsHeroTitle:    "क्या आप जानते हैं?",
    factsHeroSub:      "10 श्रेणियों में 120+ रोचक तथ्य",
    // Quotes
    quotesHeroTitle:   "आज का विचार",
    quotesHeroSub:     "10 मूड में विचार — हर दिन नया",
    todayQuote:        "आज का विचार",
    dailyPick:         "दैनिक चयन",
    browseByMood:      "मूड से खोजें:",
    moreQuotes:        "और विचार",
    total:             "कुल",
    // Games
    gamesHeroTitle:    "गेम्स शेल्फ",
    gamesHeroSub:      "10 श्रेणियों में गेम्स जल्द आ रहे हैं",
    comingSoon:        "जल्द आएगा",
    // Shayari
    shayariHeroTitle:  "शायरी",
    shayariHeroSub:    "दिल की बात, लफ़्ज़ों में — कॉपी करें और शेयर करें",
    // Music
    musicHeroTitle:    "म्यूज़िक लाउंज",
    musicHeroSub:      "लो-फाई, चिल, सूफ़ी और देसी बीट्स",
    nowPlaying:        "अभी बज रहा है",
    selectTrack:       "नीचे से ट्रैक चुनें",
    tracks:            "ट्रैक्स",
    available:         "उपलब्ध",
    stop:              "रोकें",
    // Common
    copy:              "कॉपी",
    copied:            "हो गया",
    share:             "शेयर",
    like:              "पसंद",
    liked:             "पसंद आया",
    categories:        "श्रेणियाँ",
    videos:            "वीडियो",
    hours:             "घंटे",
    source:            "स्रोत",
    language:          "हि",
  },
} as const;

export type TranslationKeys = keyof typeof translations.en;

export function t(lang: Lang, key: TranslationKeys): string {
  return translations[lang][key] ?? translations.en[key] ?? key;
}
