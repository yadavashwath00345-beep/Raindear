import { createContext, useContext, useState, useEffect, type ReactNode } from "react";
import { type Lang, t as translate, type TranslationKeys } from "@/i18n";

interface LanguageContextValue {
  lang: Lang;
  setLang: (l: Lang) => void;
  t: (key: TranslationKeys) => string;
}

const LanguageContext = createContext<LanguageContextValue>({
  lang: "en",
  setLang: () => {},
  t: (key) => key,
});

function detectDeviceLang(): Lang {
  try {
    const stored = localStorage.getItem("raindear_lang") as Lang | null;
    if (stored === "hi" || stored === "en") return stored;
    const browserLang = navigator.language || (navigator.languages?.[0] ?? "en");
    if (browserLang.startsWith("hi") || browserLang.startsWith("ur")) return "hi";
  } catch {}
  return "en";
}

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>(detectDeviceLang);

  const setLang = (l: Lang) => {
    setLangState(l);
    try { localStorage.setItem("raindear_lang", l); } catch {}
  };

  useEffect(() => {
    document.documentElement.lang = lang === "hi" ? "hi" : "en";
    document.documentElement.dir = "ltr";
  }, [lang]);

  const tFn = (key: TranslationKeys) => translate(lang, key);

  return (
    <LanguageContext.Provider value={{ lang, setLang, t: tFn }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  return useContext(LanguageContext);
}
