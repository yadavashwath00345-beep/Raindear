import { useState, useEffect, useCallback, useRef } from "react";
import { usePreferences } from "@/hooks/usePreferences";
import { LanguageProvider } from "@/contexts/LanguageContext";
import Header from "@/components/Header";
import PillNav, { type TabId } from "@/components/PillNav";
import WaveLayer from "@/components/WaveLayer";
import SearchOverlay from "@/components/SearchOverlay";
import AppFooter from "@/components/AppFooter";
import AdGate from "@/components/AdGate";
import Explore from "@/pages/Explore";
import Games from "@/pages/Games";
import Shayari from "@/pages/Shayari";
import Music from "@/pages/Music";
import Nature from "@/pages/Nature";
import Facts from "@/pages/Facts";
import Quotes from "@/pages/Quotes";
import Privacy from "@/pages/Privacy";
import About from "@/pages/About";

const VALID_TABS: TabId[] = ["explore", "nature", "facts", "quotes", "games", "shayari", "music"];
const UTIL_PAGES = ["privacy", "about"];

type PageId = TabId | "privacy" | "about";

function getPageFromHash(): PageId {
  const hash = window.location.hash.replace("#", "").toLowerCase().trim();
  if (VALID_TABS.includes(hash as TabId)) return hash as TabId;
  if (UTIL_PAGES.includes(hash)) return hash as PageId;
  return "explore";
}

function isTab(page: PageId): page is TabId {
  return VALID_TABS.includes(page as TabId);
}

function renderPage(page: PageId) {
  switch (page) {
    case "explore":  return <Explore />;
    case "games":    return <Games />;
    case "shayari":  return <Shayari />;
    case "music":    return <Music />;
    case "nature":   return <Nature />;
    case "facts":    return <Facts />;
    case "quotes":   return <Quotes />;
    case "privacy":  return <Privacy />;
    case "about":    return <About />;
    default:         return <Explore />;
  }
}

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
}

function AppInner() {
  const { prefs, toggleMusic, toggleVibration } = usePreferences();
  const [activePage, setActivePage] = useState<PageId>(getPageFromHash);
  const [installPrompt, setInstallPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [toastMsg, setToastMsg] = useState<string | null>(null);
  const [searchOpen, setSearchOpen] = useState(false);
  const [adDone, setAdDone] = useState(false);
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const showToast = useCallback((msg: string) => {
    setToastMsg(msg);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToastMsg(null), 2200);
  }, []);

  const navigateTo = useCallback((page: PageId) => {
    if (page === activePage) return;
    window.history.pushState({ page }, "", `#${page}`);
    setActivePage(page);
  }, [activePage]);

  useEffect(() => {
    const onPopState = (e: PopStateEvent) => {
      const page = (e.state?.page as PageId) || getPageFromHash();
      setActivePage(page);
    };
    window.addEventListener("popstate", onPopState);
    const initial = getPageFromHash();
    window.history.replaceState({ page: initial }, "", `#${initial}`);
    setActivePage(initial);
    return () => window.removeEventListener("popstate", onPopState);
  }, []);

  useEffect(() => {
    const handler = (e: Event) => {
      e.preventDefault();
      setInstallPrompt(e as BeforeInstallPromptEvent);
    };
    window.addEventListener("beforeinstallprompt", handler);
    return () => window.removeEventListener("beforeinstallprompt", handler);
  }, []);

  const handleInstall = useCallback(async () => {
    if (!installPrompt) return;
    await installPrompt.prompt();
    const result = await installPrompt.userChoice;
    if (result.outcome === "accepted") {
      setInstallPrompt(null);
      showToast("Raindear installed! 🎉");
    }
  }, [installPrompt, showToast]);

  const activeTab = isTab(activePage) ? activePage : "explore";

  return (
    <>
      <div className="raindear-bg" aria-hidden="true" />
      <div className="raindear-stars" aria-hidden="true" />
      <div className="raindear-glows" aria-hidden="true">
        <div className="glow-blob glow-blob-1" />
        <div className="glow-blob glow-blob-2" />
        <div className="glow-blob glow-blob-3" />
      </div>
      <WaveLayer />

      {/* Daily ad gate — shows once per 24 hours on app open */}
      <AdGate onDone={() => setAdDone(true)} />

      <SearchOverlay open={searchOpen} onClose={() => setSearchOpen(false)} />

      <div
        style={{
          height: "100dvh",
          display: "flex",
          flexDirection: "column",
          maxWidth: 720,
          width: "100%",
          margin: "0 auto",
          position: "relative",
          overflow: "hidden",
          /* Blur app behind ad gate until ad is done */
          filter: adDone ? "none" : "blur(8px)",
          transition: "filter 0.4s ease",
          pointerEvents: adDone ? "auto" : "none",
        }}
        data-testid="app-root"
      >
        <Header
          musicOn={prefs.musicOn}
          vibrationOn={prefs.vibrationOn}
          onToggleMusic={toggleMusic}
          onToggleVibration={toggleVibration}
          showInstall={!!installPrompt}
          onInstall={handleInstall}
          onSearch={() => setSearchOpen(true)}
        />

        {isTab(activePage) ? (
          <PillNav
            active={activeTab}
            onSelect={(tab) => navigateTo(tab)}
            vibrationOn={prefs.vibrationOn}
          />
        ) : (
          <div
            style={{
              padding: "0.6rem 1rem",
              background: "rgba(0,0,0,0.15)",
              borderBottom: "1px solid rgba(255,255,255,0.06)",
              flexShrink: 0,
            }}
          >
            <button
              onClick={() => navigateTo("explore")}
              style={{
                display: "flex",
                alignItems: "center",
                gap: "0.4rem",
                background: "rgba(255,255,255,0.07)",
                border: "1px solid rgba(255,255,255,0.12)",
                borderRadius: "9999px",
                padding: "0.35rem 0.9rem",
                color: "rgba(255,255,255,0.75)",
                fontSize: "0.78rem",
                fontWeight: 500,
                fontFamily: "'Poppins', sans-serif",
                cursor: "pointer",
                touchAction: "manipulation",
              }}
            >
              ← Back
            </button>
          </div>
        )}

        <main className="main-scroll" data-testid="main-content">
          {renderPage(activePage)}
          <AppFooter onNavigate={navigateTo} />
        </main>
      </div>

      {toastMsg && (
        <div className="toast-container">
          <div className="toast">{toastMsg}</div>
        </div>
      )}
    </>
  );
}

export default function App() {
  return (
    <LanguageProvider>
      <AppInner />
    </LanguageProvider>
  );
}
