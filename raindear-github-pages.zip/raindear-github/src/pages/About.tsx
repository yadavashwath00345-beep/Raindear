import { useLanguage } from "@/contexts/LanguageContext";

export default function About() {
  const { lang } = useLanguage();

  const features = lang === "hi" ? [
    { icon: "🌅", title: "खोजें", desc: "शायरी, हॉरर, फ़ैशन और न्यूज़ वीडियो" },
    { icon: "🌿", title: "प्रकृति", desc: "जंगल, समुद्र, पहाड़ — सुकून पाएं" },
    { icon: "💡", title: "तथ्य", desc: "120+ रोचक तथ्य 10 श्रेणियों में" },
    { icon: "✨", title: "विचार", desc: "171+ कोट्स — हर दिन नया" },
    { icon: "✍️", title: "शायरी", desc: "दिल की बात, लफ़्ज़ों में" },
    { icon: "🎵", title: "संगीत", desc: "लो-फाई, चिल, सूफ़ी बीट्स" },
    { icon: "🎮", title: "खेल", desc: "गेम्स जल्द आ रहे हैं" },
  ] : [
    { icon: "🌅", title: "Explore", desc: "Shayari, Horror, Fashion & News videos" },
    { icon: "🌿", title: "Nature", desc: "Forest, ocean, mountain sounds — unwind" },
    { icon: "💡", title: "Facts", desc: "120+ mind-blowing facts across 10 categories" },
    { icon: "✨", title: "Quotes", desc: "171+ quotes — a new one every day" },
    { icon: "✍️", title: "Shayari", desc: "Dil ki baat, lafzon mein" },
    { icon: "🎵", title: "Music", desc: "Lo-fi, Chill, Sufi & Desi beats" },
    { icon: "🎮", title: "Games", desc: "Games coming soon" },
  ];

  return (
    <div className="page-pad page-enter">
      <div style={{ maxWidth: 680, margin: "0 auto" }}>

        {/* Hero */}
        <div
          style={{
            background: "linear-gradient(135deg, rgba(26,42,108,0.8) 0%, rgba(178,31,31,0.6) 60%, rgba(253,187,45,0.2) 100%)",
            border: "1px solid rgba(255,255,255,0.12)",
            borderRadius: "1.2rem",
            padding: "2rem 1.5rem",
            marginBottom: "1.25rem",
            textAlign: "center",
            position: "relative",
            overflow: "hidden",
          }}
        >
          {/* Logo */}
          <div
            style={{
              width: 72, height: 72,
              borderRadius: "50%",
              background: "linear-gradient(135deg, #fdbb2d 0%, #e06c1a 50%, #b21f1f 100%)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              margin: "0 auto 1rem",
              boxShadow: "0 8px 32px rgba(253,187,45,0.45)",
              fontSize: "2rem",
            }}
          >
            🎵
          </div>

          <h1
            style={{
              fontFamily: "'Dancing Script', cursive",
              fontSize: "2.4rem",
              fontWeight: 700,
              background: "linear-gradient(135deg, #fdbb2d 0%, #fff 60%)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
              backgroundClip: "text",
              marginBottom: "0.4rem",
            }}
          >
            Raindear
          </h1>

          <p
            style={{
              fontSize: "0.88rem",
              color: "rgba(255,255,255,0.7)",
              lineHeight: 1.6,
              maxWidth: 420,
              margin: "0 auto",
            }}
          >
            {lang === "hi"
              ? "आपकी अपनी दुनिया — शायरी, संगीत, तथ्य और प्रकृति का सुंदर संगम। एक प्रीमियम PWA अनुभव।"
              : "Your personal world — a premium space for Shayari, Music, Facts, and Nature. Free. Beautiful. Yours."}
          </p>
        </div>

        {/* Features grid */}
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(2, 1fr)",
            gap: "0.7rem",
            marginBottom: "1.25rem",
          }}
        >
          {features.map((f, i) => (
            <div
              key={i}
              style={{
                background: "rgba(255,255,255,0.05)",
                border: "1px solid rgba(255,255,255,0.09)",
                borderRadius: "0.9rem",
                padding: "1rem",
                backdropFilter: "blur(14px)",
              }}
            >
              <div style={{ fontSize: "1.6rem", marginBottom: "0.4rem" }}>{f.icon}</div>
              <div style={{ fontSize: "0.85rem", fontWeight: 700, color: "#fff", marginBottom: "0.2rem" }}>
                {f.title}
              </div>
              <div style={{ fontSize: "0.72rem", color: "rgba(255,255,255,0.5)", lineHeight: 1.45 }}>
                {f.desc}
              </div>
            </div>
          ))}
        </div>

        {/* Stats */}
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(3, 1fr)",
            gap: "0.7rem",
            marginBottom: "1.25rem",
          }}
        >
          {[
            { num: "64+", label: lang === "hi" ? "वीडियो" : "Videos" },
            { num: "171+", label: lang === "hi" ? "विचार" : "Quotes" },
            { num: "120+", label: lang === "hi" ? "तथ्य" : "Facts" },
          ].map((s, i) => (
            <div
              key={i}
              style={{
                background: "rgba(253,187,45,0.07)",
                border: "1px solid rgba(253,187,45,0.18)",
                borderRadius: "0.9rem",
                padding: "1rem 0.5rem",
                textAlign: "center",
              }}
            >
              <div
                style={{
                  fontSize: "1.6rem",
                  fontWeight: 800,
                  background: "linear-gradient(135deg, #fdbb2d, #fff)",
                  WebkitBackgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                  backgroundClip: "text",
                }}
              >
                {s.num}
              </div>
              <div style={{ fontSize: "0.7rem", color: "rgba(255,255,255,0.5)", marginTop: "0.2rem" }}>
                {s.label}
              </div>
            </div>
          ))}
        </div>

        {/* PWA install card */}
        <div
          style={{
            background: "rgba(255,255,255,0.05)",
            border: "1px solid rgba(255,255,255,0.1)",
            borderRadius: "1rem",
            padding: "1.2rem 1.25rem",
            marginBottom: "1.25rem",
          }}
        >
          <h3 style={{ fontSize: "0.9rem", fontWeight: 700, color: "#fff", marginBottom: "0.6rem" }}>
            📱 {lang === "hi" ? "ऐप की तरह इंस्टॉल करें" : "Install like a native app"}
          </h3>
          <p style={{ fontSize: "0.8rem", color: "rgba(255,255,255,0.6)", lineHeight: 1.65 }}>
            {lang === "hi"
              ? "Android पर Chrome में 'होम स्क्रीन पर जोड़ें' टैप करें। iPhone पर Safari में Share → 'होम स्क्रीन पर जोड़ें' चुनें। कोई App Store नहीं — बिल्कुल मुफ्त!"
              : "On Android: tap the Chrome menu → \"Add to Home Screen\". On iPhone: open in Safari → Share → \"Add to Home Screen\". No App Store needed — completely free!"}
          </p>
        </div>

        {/* Contact & links */}
        <div
          style={{
            background: "rgba(255,255,255,0.04)",
            border: "1px solid rgba(255,255,255,0.08)",
            borderRadius: "1rem",
            padding: "1.2rem 1.25rem",
          }}
        >
          <h3 style={{ fontSize: "0.9rem", fontWeight: 700, color: "#fff", marginBottom: "0.8rem" }}>
            {lang === "hi" ? "संपर्क करें" : "Contact"}
          </h3>
          {[
            { label: lang === "hi" ? "ईमेल" : "Email", value: "raindear.app@gmail.com" },
            { label: lang === "hi" ? "गोपनीयता नीति" : "Privacy Policy", value: "#privacy" },
          ].map((item, i) => (
            <div
              key={i}
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                padding: "0.6rem 0",
                borderTop: i > 0 ? "1px solid rgba(255,255,255,0.07)" : "none",
              }}
            >
              <span style={{ fontSize: "0.8rem", color: "rgba(255,255,255,0.5)" }}>{item.label}</span>
              <span style={{ fontSize: "0.8rem", color: "#fdbb2d", fontWeight: 500 }}>{item.value}</span>
            </div>
          ))}
        </div>

        <div
          style={{
            textAlign: "center",
            marginTop: "1.5rem",
            fontSize: "0.72rem",
            color: "rgba(255,255,255,0.28)",
          }}
        >
          {lang === "hi" ? "प्यार से बनाया गया 🌅" : "Made with 🌅 by Raindear"}
        </div>

      </div>
    </div>
  );
}
