import { useState } from "react";

type FactCategory = "science" | "india" | "space" | "history" | "animals" | "tech" | "human" | "weird" | "food" | "ocean";

interface Fact {
  text: string;
  source?: string;
  emoji?: string;
}

const CATEGORIES: { id: FactCategory; label: string; color: string }[] = [
  { id: "science",  label: "🔬 Science",  color: "#4f46e5" },
  { id: "india",    label: "🇮🇳 India",   color: "#ff6600" },
  { id: "space",    label: "🚀 Space",    color: "#0891b2" },
  { id: "history",  label: "📜 History",  color: "#92400e" },
  { id: "animals",  label: "🐾 Animals",  color: "#047857" },
  { id: "tech",     label: "💻 Tech",     color: "#7c3aed" },
  { id: "human",    label: "🧠 Human Body", color: "#b21f1f" },
  { id: "weird",    label: "🤯 Weird",    color: "#9d174d" },
  { id: "food",     label: "🍜 Food",     color: "#d97706" },
  { id: "ocean",    label: "🌊 Ocean",    color: "#1d4ed8" },
];

const FACTS: Record<FactCategory, Fact[]> = {
  science: [
    { emoji: "⚡", text: "Lightning strikes Earth about 100 times every second.", source: "NASA" },
    { emoji: "💧", text: "Water can boil and freeze at the same time — it's called the 'triple point'.", source: "Physics" },
    { emoji: "🧲", text: "A teaspoon of neutron star material would weigh about 10 million tonnes.", source: "Astrophysics" },
    { emoji: "🌡️", text: "The hottest place on Earth is Furnace Creek, California at 56.7°C (134°F).", source: "WMO" },
    { emoji: "🔥", text: "The Sun's core temperature is about 15 million degrees Celsius.", source: "NASA" },
    { emoji: "🧬", text: "Human DNA, if uncoiled, would stretch from Earth to Pluto and back — 17 times.", source: "Biology" },
    { emoji: "🌪️", text: "A day on Venus is longer than a year on Venus.", source: "NASA" },
    { emoji: "🪨", text: "Diamonds can be made from peanut butter under extreme pressure.", source: "Chemistry" },
    { emoji: "🌈", text: "Glass is neither a solid nor a liquid — it's an amorphous solid.", source: "Materials Science" },
    { emoji: "🔭", text: "There are more stars in the universe than grains of sand on all Earth's beaches.", source: "Astronomy" },
    { emoji: "🦠", text: "A sneeze travels at about 160 km/h — faster than a hurricane.", source: "Biology" },
    { emoji: "💡", text: "Honey never spoils — 3000-year-old honey found in Egyptian tombs was still edible.", source: "Archaeology" },
  ],
  india: [
    { emoji: "🧮", text: "India invented the number system (0–9). Without it, modern math wouldn't exist.", source: "History" },
    { emoji: "♟️", text: "Chess was invented in India around the 6th century AD, called 'Chaturanga'.", source: "History" },
    { emoji: "🏏", text: "India is the only country to have won the Cricket World Cup under two different formats.", source: "ICC" },
    { emoji: "🌶️", text: "India produces about 70% of the world's spices.", source: "FAO" },
    { emoji: "🛕", text: "India has over 2 million temples — more than any other country.", source: "ASI" },
    { emoji: "🚂", text: "Indian Railways is the world's 4th largest rail network — 68,000+ km of track.", source: "IR" },
    { emoji: "📐", text: "The value of Pi was first calculated by the Indian mathematician Aryabhata in 499 AD.", source: "Mathematics" },
    { emoji: "💊", text: "Ayurveda, the world's oldest healthcare system, originated in India over 5000 years ago.", source: "WHO" },
    { emoji: "🌊", text: "India has the largest number of vegetarians in the world — about 375 million.", source: "Statistics" },
    { emoji: "🏙️", text: "Mumbai's Dharavi is Asia's largest slum, yet generates $1 billion GDP annually.", source: "Economics" },
    { emoji: "🎯", text: "India is the largest democracy in the world with over 900 million eligible voters.", source: "ECI" },
    { emoji: "💻", text: "India has the second-largest pool of software developers in the world.", source: "NASSCOM" },
  ],
  space: [
    { emoji: "🌑", text: "One million Earths could fit inside the Sun.", source: "NASA" },
    { emoji: "🚀", text: "In space, astronauts grow about 2 inches taller due to spine expansion.", source: "NASA" },
    { emoji: "⭐", text: "There are more atoms in a glass of water than glasses of water in all Earth's oceans.", source: "Physics" },
    { emoji: "🪐", text: "Saturn's rings are only about 20 metres thick but span 282,000 km wide.", source: "Cassini" },
    { emoji: "🌌", text: "The Milky Way galaxy is 100,000 light-years across.", source: "ESA" },
    { emoji: "🌕", text: "The Moon moves 3.8 cm away from Earth every year.", source: "NASA" },
    { emoji: "☄️", text: "A comet's tail always points away from the Sun, regardless of direction of travel.", source: "Astronomy" },
    { emoji: "🔭", text: "Light from the Sun takes 8 minutes and 20 seconds to reach Earth.", source: "Physics" },
    { emoji: "🌠", text: "The observable universe is about 93 billion light-years in diameter.", source: "Cosmology" },
    { emoji: "🪨", text: "Mars has the largest volcano in the solar system — Olympus Mons, 22 km high.", source: "NASA" },
    { emoji: "💫", text: "Black holes don't suck — they pull everything toward them like any massive object.", source: "Physics" },
    { emoji: "🛸", text: "Space is completely silent — sound needs a medium to travel through.", source: "Physics" },
  ],
  history: [
    { emoji: "🏛️", text: "Ancient Romans used urine as mouthwash and teeth whitener.", source: "Archaeology" },
    { emoji: "🗿", text: "Cleopatra lived closer to the Moon landing (1969) than to the building of the Great Pyramid.", source: "History" },
    { emoji: "🗡️", text: "Oxford University is older than the Aztec Empire.", source: "Academic History" },
    { emoji: "🌍", text: "The shortest war in history lasted 38–45 minutes — between Britain and Zanzibar in 1896.", source: "History" },
    { emoji: "🏰", text: "The Great Wall of China was built over 2,000 years — multiple dynasties worked on it.", source: "UNESCO" },
    { emoji: "⚔️", text: "Vikings used the bones of slain animals to sharpen their swords.", source: "Archaeology" },
    { emoji: "📜", text: "The Library of Alexandria held an estimated 700,000 scrolls.", source: "Ancient History" },
    { emoji: "🎭", text: "Shakespeare invented over 1,700 words we still use today — 'bedroom', 'lonely', 'generous'.", source: "Literature" },
    { emoji: "🐘", text: "Hannibal crossed the Alps with war elephants to invade Rome in 218 BC.", source: "Roman History" },
    { emoji: "🧭", text: "Columbus never actually reached mainland America — he landed in the Caribbean.", source: "Exploration" },
    { emoji: "🪖", text: "WWI was triggered by the assassination of Archduke Franz Ferdinand — a chance encounter.", source: "WWI History" },
    { emoji: "💣", text: "More people were killed by the Spanish Flu (1918) than in all of WWI.", source: "Medical History" },
  ],
  animals: [
    { emoji: "🐘", text: "Elephants are the only animals that can't jump.", source: "Zoology" },
    { emoji: "🦈", text: "Sharks are older than trees — they've existed for over 450 million years.", source: "Paleontology" },
    { emoji: "🐙", text: "Octopuses have 3 hearts, blue blood, and 9 brains (1 main + 8 in their arms).", source: "Marine Biology" },
    { emoji: "🦁", text: "A lion's roar can be heard 8 km away.", source: "Zoology" },
    { emoji: "🐝", text: "Bees can recognize human faces.", source: "Animal Behaviour" },
    { emoji: "🐋", text: "Blue whales' hearts are so large a small human could crawl through the arteries.", source: "Marine Biology" },
    { emoji: "🐌", text: "A snail can sleep for 3 years straight.", source: "Zoology" },
    { emoji: "🦋", text: "Butterflies taste with their feet — they have taste sensors on their legs.", source: "Entomology" },
    { emoji: "🦅", text: "Eagles can spot a rabbit from 3 km away.", source: "Ornithology" },
    { emoji: "🐬", text: "Dolphins have names for each other and call out to specific individuals.", source: "Marine Biology" },
    { emoji: "🐊", text: "Crocodiles can't stick out their tongues — they have fixed tongues.", source: "Reptile Biology" },
    { emoji: "🐜", text: "Ants can lift 50 times their own body weight.", source: "Entomology" },
  ],
  tech: [
    { emoji: "💾", text: "The first computer bug was a literal bug — a moth found inside a Harvard computer in 1947.", source: "Computing History" },
    { emoji: "📱", text: "Your smartphone is millions of times more powerful than the computers that sent humans to the Moon.", source: "Computing" },
    { emoji: "🌐", text: "The internet weighs about 50 grams — the mass of electrons carrying all data.", source: "Physics" },
    { emoji: "🤖", text: "GPT-4 was trained on roughly 45 terabytes of text data.", source: "OpenAI" },
    { emoji: "💻", text: "The first website ever created is still live — it's at info.cern.ch.", source: "CERN" },
    { emoji: "📷", text: "More photos are taken every 2 minutes than existed in total in the 1800s.", source: "Statistics" },
    { emoji: "🔋", text: "If the entire internet were printed, it would fill 305 billion printed pages.", source: "Tech Research" },
    { emoji: "🎮", text: "The video game industry generates more revenue than movies and music combined.", source: "Industry Data" },
    { emoji: "📡", text: "WiFi 6 can theoretically reach 9.6 Gbps — enough to download 4K movies in seconds.", source: "IEEE" },
    { emoji: "🖥️", text: "The first computer mouse was made of wood.", source: "Computing History" },
    { emoji: "☁️", text: "Google processes about 8.5 billion searches per day.", source: "Google Stats" },
    { emoji: "🔐", text: "It would take 1 trillion years to crack a 128-bit AES encrypted message.", source: "Cryptography" },
  ],
  human: [
    { emoji: "🫀", text: "Your heart beats about 100,000 times a day — 37 million times a year.", source: "Cardiology" },
    { emoji: "🧠", text: "The human brain generates about 23 watts of power — enough to light a dim bulb.", source: "Neuroscience" },
    { emoji: "👁️", text: "The human eye can detect about 10 million different colors.", source: "Ophthalmology" },
    { emoji: "🦴", text: "Babies are born with 270 bones — adults have only 206 (they fuse over time).", source: "Anatomy" },
    { emoji: "💧", text: "The human body is about 60% water — the brain is 73% water.", source: "Biology" },
    { emoji: "🧬", text: "You share 60% of your DNA with a banana.", source: "Genetics" },
    { emoji: "👃", text: "Humans can detect 1 trillion different smells.", source: "Olfaction Research" },
    { emoji: "💪", text: "The strongest muscle relative to size in the human body is the masseter (jaw muscle).", source: "Anatomy" },
    { emoji: "🩸", text: "Your blood vessels, if laid end to end, would circle Earth 4 times.", source: "Anatomy" },
    { emoji: "😴", text: "Humans are the only animals that blush.", source: "Anthropology" },
    { emoji: "✋", text: "Fingernails grow faster on your dominant hand and in summer.", source: "Dermatology" },
    { emoji: "🧪", text: "The acid in your stomach is strong enough to dissolve zinc.", source: "Biology" },
  ],
  weird: [
    { emoji: "🌊", text: "There is a lake in Africa (Lake Natron) that turns animals to stone due to its alkalinity.", source: "Geography" },
    { emoji: "🌩️", text: "There is a perpetual lightning storm over Venezuela's Lake Maracaibo — 260 nights a year.", source: "Meteorology" },
    { emoji: "🔵", text: "A 'blue moon' actually appears blue sometimes — it happens after volcanic eruptions.", source: "Astronomy" },
    { emoji: "🧊", text: "Hot water can freeze faster than cold water under certain conditions (Mpemba Effect).", source: "Physics" },
    { emoji: "🐟", text: "There are more fake flamingos in the world than real flamingos.", source: "Statistics" },
    { emoji: "🌐", text: "Alaska is the easternmost, westernmost, AND northernmost US state simultaneously.", source: "Geography" },
    { emoji: "💤", text: "Sea otters hold hands while sleeping so they don't drift apart.", source: "Marine Biology" },
    { emoji: "🎵", text: "The national anthem of Greece has 158 verses.", source: "Culture" },
    { emoji: "🌡️", text: "Bananas are slightly radioactive due to their potassium content.", source: "Nuclear Physics" },
    { emoji: "🌱", text: "Grass makes a sound when it grows — it's just too high-pitched for humans to hear.", source: "Botany" },
    { emoji: "🗺️", text: "France has the most time zones of any country — 12 in total due to its territories.", source: "Geography" },
    { emoji: "🐈", text: "Cats can't taste sweetness — they lack the taste receptor for sugar.", source: "Feline Biology" },
  ],
  food: [
    { emoji: "🍕", text: "Italians eat about 1.4 million tonnes of pizza per year.", source: "Food Stats" },
    { emoji: "🍫", text: "It takes about 400 cocoa beans to make 450g of chocolate.", source: "Food Science" },
    { emoji: "🧅", text: "Cutting onions makes you cry because they release sulphur compounds that irritate your eyes.", source: "Chemistry" },
    { emoji: "🍯", text: "Honey is the only food that doesn't spoil — it can last 3,000+ years.", source: "Archaeology" },
    { emoji: "🥑", text: "Avocados are berries, but strawberries are not — botanically speaking.", source: "Botany" },
    { emoji: "🌶️", text: "Capsaicin — the compound that makes chilli hot — is measured in Scoville units.", source: "Food Chemistry" },
    { emoji: "🍑", text: "Almonds are not nuts — they're seeds of a drupe fruit, related to peaches.", source: "Botany" },
    { emoji: "🧀", text: "Cheese is the most stolen food in the world — about 4% of all cheese produced is stolen.", source: "INTERPOL" },
    { emoji: "🍌", text: "Bananas are curved because they grow toward the Sun.", source: "Botany" },
    { emoji: "☕", text: "Coffee is the second most traded commodity in the world after oil.", source: "Trade Stats" },
    { emoji: "🧂", text: "Salt was once so valuable it was used as currency — the word 'salary' comes from salt.", source: "Etymology" },
    { emoji: "🍎", text: "Apples float in water because they are 25% air.", source: "Food Science" },
  ],
  ocean: [
    { emoji: "🌊", text: "The ocean covers 71% of Earth's surface but over 80% remains unexplored.", source: "NOAA" },
    { emoji: "🐙", text: "The Mariana Trench is 11 km deep — deeper than Everest is tall.", source: "NOAA" },
    { emoji: "🌡️", text: "The average ocean depth is 3.7 km — about 12,000 feet.", source: "Oceanography" },
    { emoji: "🔵", text: "The Pacific Ocean is larger than all of Earth's landmasses combined.", source: "Geography" },
    { emoji: "💨", text: "The ocean produces over 50% of Earth's oxygen — mostly from phytoplankton.", source: "NOAA" },
    { emoji: "🧂", text: "If all the ocean's salt were spread on land, it would be 500 feet deep.", source: "Oceanography" },
    { emoji: "🦑", text: "The Giant Squid has eyes the size of dinner plates — 30 cm diameter.", source: "Marine Biology" },
    { emoji: "🌊", text: "Ocean waves can travel thousands of kilometres before breaking on a shore.", source: "Physics" },
    { emoji: "🐋", text: "Whale songs can be heard 800 km away underwater.", source: "Marine Biology" },
    { emoji: "💎", text: "There is more gold dissolved in seawater than has ever been mined on land.", source: "Geochemistry" },
    { emoji: "🌱", text: "Kelp forests grow up to 60 cm per day — the fastest growing plants on Earth.", source: "Marine Biology" },
    { emoji: "🌀", text: "The Great Pacific Garbage Patch is twice the size of Texas.", source: "NOAA" },
  ],
};

function FactCard({ fact, index, color }: { fact: Fact; index: number; color: string }) {
  const [liked, setLiked] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard?.writeText(`${fact.emoji} ${fact.text}${fact.source ? ` — ${fact.source}` : ""}`).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div
      className="glass-card shimmer"
      data-testid={`fact-card-${index}`}
      style={{
        padding: "1rem 1rem 1rem",
        position: "relative",
        borderLeft: `3px solid ${color}55`,
        transition: "transform 0.25s",
      }}
    >
      <div style={{ display: "flex", gap: "0.75rem", alignItems: "flex-start" }}>
        <div
          style={{
            fontSize: "1.65rem",
            flexShrink: 0,
            lineHeight: 1.1,
            filter: "drop-shadow(0 2px 4px rgba(0,0,0,0.3))",
          }}
        >
          {fact.emoji}
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <p
            style={{
              fontSize: "0.875rem",
              color: "rgba(255,255,255,0.9)",
              lineHeight: 1.65,
              fontWeight: 400,
              margin: 0,
            }}
          >
            {fact.text}
          </p>
          {fact.source && (
            <div
              style={{
                marginTop: "0.45rem",
                fontSize: "0.65rem",
                color: color,
                fontWeight: 600,
                letterSpacing: "0.06em",
                textTransform: "uppercase",
                opacity: 0.75,
              }}
            >
              Source: {fact.source}
            </div>
          )}
        </div>
      </div>

      {/* Actions */}
      <div
        style={{
          display: "flex",
          gap: "0.5rem",
          marginTop: "0.75rem",
          justifyContent: "flex-end",
        }}
      >
        <button
          onClick={() => setLiked((l) => !l)}
          style={{
            background: liked ? "rgba(239,68,68,0.2)" : "rgba(255,255,255,0.07)",
            border: `1px solid ${liked ? "rgba(239,68,68,0.4)" : "rgba(255,255,255,0.12)"}`,
            borderRadius: "0.4rem",
            padding: "0.22rem 0.65rem",
            fontSize: "0.7rem",
            color: liked ? "#f87171" : "rgba(255,255,255,0.4)",
            cursor: "pointer",
            transition: "all 0.2s",
            fontFamily: "'Poppins', sans-serif",
            fontWeight: 600,
          }}
        >
          {liked ? "❤️ Liked" : "♡ Like"}
        </button>
        <button
          className={`copy-btn ${copied ? "copied" : ""}`}
          onClick={handleCopy}
          style={{ position: "static" }}
        >
          {copied ? "✓ Copied" : "Share"}
        </button>
      </div>
    </div>
  );
}

export default function Facts() {
  const [activeCategory, setActiveCategory] = useState<FactCategory>("india");
  const facts = FACTS[activeCategory];
  const catObj = CATEGORIES.find((c) => c.id === activeCategory)!;

  return (
    <div className="page-enter" data-testid="page-facts">
      <div className="page-pad">

        {/* Hero */}
        <div
          className="hero-banner shimmer"
          style={{
            marginBottom: "1.1rem",
            background: `linear-gradient(135deg, rgba(79,70,229,0.5) 0%, rgba(26,42,108,0.75) 60%, rgba(253,187,45,0.1) 100%)`,
          }}
        >
          <div className="hero-title" style={{ fontFamily: "'Poppins', sans-serif", fontSize: "1.4rem", fontWeight: 800 }}>
            💡 Did You Know?
          </div>
          <p className="hero-subtitle">
            120+ mind-blowing facts across 10 categories — science, India, space & more
          </p>
        </div>

        {/* Category Tabs */}
        <div className="cat-tabs" style={{ marginBottom: "1.25rem", flexWrap: "nowrap" }}>
          {CATEGORIES.map((cat) => (
            <button
              key={cat.id}
              className={`cat-tab ${activeCategory === cat.id ? "active" : ""}`}
              onClick={() => setActiveCategory(cat.id)}
              data-testid={`facts-cat-${cat.id}`}
              style={activeCategory === cat.id ? {
                background: `${cat.color}22`,
                borderColor: `${cat.color}66`,
                color: cat.color,
              } : {}}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Fact Count */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            marginBottom: "0.85rem",
          }}
        >
          <div style={{ fontSize: "0.75rem", color: "rgba(255,255,255,0.45)" }}>
            {catObj.label} — {facts.length} facts
          </div>
          <div
            className="badge"
            style={{
              background: `${catObj.color}22`,
              color: catObj.color,
              border: `1px solid ${catObj.color}44`,
            }}
          >
            ❤️ Tap to like
          </div>
        </div>

        {/* Fact Cards */}
        <div style={{ display: "flex", flexDirection: "column", gap: "0.75rem" }}>
          {facts.map((fact, i) => (
            <FactCard
              key={`${activeCategory}-${i}`}
              fact={fact}
              index={i}
              color={catObj.color}
            />
          ))}
        </div>

        {/* Total count footer */}
        <div
          className="glass-card"
          style={{ padding: "1rem", marginTop: "1.25rem", textAlign: "center", borderColor: "rgba(253,187,45,0.2)" }}
        >
          <div style={{ fontSize: "1.1rem", fontWeight: 800, color: "#fdbb2d" }}>120+</div>
          <div style={{ fontSize: "0.78rem", color: "rgba(255,255,255,0.5)", marginTop: "0.2rem" }}>
            Total facts across all categories — more added regularly
          </div>
        </div>
      </div>
    </div>
  );
}
