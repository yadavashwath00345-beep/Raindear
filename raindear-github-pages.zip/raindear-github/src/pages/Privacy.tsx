import { useLanguage } from "@/contexts/LanguageContext";

export default function Privacy() {
  const { lang } = useLanguage();

  const sections = lang === "hi" ? [
    {
      title: "गोपनीयता नीति",
      body: `अंतिम अपडेट: जनवरी 2025\n\nRaindear ("हम", "हमारा") आपकी गोपनीयता की परवाह करता है। यह नीति बताती है कि हम कौन सी जानकारी एकत्र करते हैं और इसका उपयोग कैसे करते हैं।`,
    },
    {
      title: "हम क्या जानकारी एकत्र करते हैं",
      body: `• कोई व्यक्तिगत जानकारी नहीं: हम आपका नाम, ईमेल, फोन नंबर या कोई भी व्यक्तिगत डेटा एकत्र नहीं करते।\n• स्थानीय संग्रहण: आपकी प्राथमिकताएं (भाषा, म्यूज़िक सेटिंग) केवल आपके डिवाइस पर संग्रहीत की जाती हैं।\n• कुकीज़: हम विश्लेषण और विज्ञापन के लिए तृतीय-पक्ष कुकीज़ (Google AdSense) का उपयोग करते हैं।`,
    },
    {
      title: "Google AdSense और विज्ञापन",
      body: `हम Google AdSense का उपयोग करते हैं। Google आपकी रुचियों के आधार पर विज्ञापन दिखाने के लिए कुकीज़ का उपयोग कर सकता है। आप Google के विज्ञापन सेटिंग पर जाकर इसे नियंत्रित कर सकते हैं: https://adssettings.google.com`,
    },
    {
      title: "YouTube वीडियो",
      body: `हमारा ऐप YouTube के एम्बेडेड वीडियो का उपयोग करता है। जब आप कोई वीडियो चलाते हैं, तो YouTube की गोपनीयता नीति लागू होती है: https://policies.google.com/privacy`,
    },
    {
      title: "आपके अधिकार",
      body: `आप किसी भी समय अपनी स्थानीय संग्रहण डेटा को साफ़ कर सकते हैं (Settings → Clear browsing data)। हम किसी भी बाहरी सर्वर पर आपका डेटा नहीं भेजते।`,
    },
    {
      title: "संपर्क करें",
      body: `किसी प्रश्न के लिए हमसे संपर्क करें:\nraindear.app@gmail.com`,
    },
  ] : [
    {
      title: "Privacy Policy",
      body: `Last updated: January 2025\n\nRaindear ("we", "our") cares about your privacy. This policy explains what information we collect and how we use it.`,
    },
    {
      title: "What We Collect",
      body: `• No personal data: We do not collect your name, email, phone number, or any personal information.\n• Local storage: Your preferences (language, music settings, liked items) are stored only on your device — never on a server.\n• Cookies: We use third-party cookies (Google AdSense) for analytics and advertising purposes.`,
    },
    {
      title: "Google AdSense & Advertising",
      body: `We use Google AdSense to show advertisements. Google may use cookies to show you relevant ads based on your browsing behaviour. You can manage your ad preferences at: https://adssettings.google.com\n\nThis site is compliant with Google's advertising policies. Ads are not shown on pages containing YouTube-embedded video content.`,
    },
    {
      title: "YouTube Embedded Videos",
      body: `This app embeds videos from YouTube. When you play a video, YouTube's privacy policy applies. Please review it at: https://policies.google.com/privacy\n\nWe do not run any third-party advertising alongside YouTube embedded content.`,
    },
    {
      title: "Your Rights",
      body: `You can clear your locally stored data at any time via your browser/phone settings (Settings → Clear browsing data → Cached data & cookies). We do not transmit your data to any external server.`,
    },
    {
      title: "Children",
      body: `Raindear is not directed to children under 13. We do not knowingly collect information from children.`,
    },
    {
      title: "Changes to This Policy",
      body: `We may update this policy. Continued use of the app after changes means you accept the updated policy.`,
    },
    {
      title: "Contact",
      body: `For any questions about this policy, contact us at:\nraindear.app@gmail.com`,
    },
  ];

  return (
    <div className="page-pad page-enter">
      <div style={{ maxWidth: 680, margin: "0 auto" }}>

        {/* Header */}
        <div
          style={{
            background: "linear-gradient(135deg, rgba(26,42,108,0.75) 0%, rgba(178,31,31,0.45) 100%)",
            border: "1px solid rgba(255,255,255,0.1)",
            borderRadius: "1rem",
            padding: "1.5rem",
            marginBottom: "1.25rem",
            textAlign: "center",
          }}
        >
          <div style={{ fontSize: "2.5rem", marginBottom: "0.5rem" }}>🔒</div>
          <h1
            style={{
              fontFamily: "'Dancing Script', cursive",
              fontSize: "2rem",
              fontWeight: 700,
              background: "linear-gradient(135deg, #fdbb2d, #fff 60%)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
              backgroundClip: "text",
              marginBottom: "0.25rem",
            }}
          >
            {lang === "hi" ? "गोपनीयता नीति" : "Privacy Policy"}
          </h1>
          <p style={{ fontSize: "0.78rem", color: "rgba(255,255,255,0.5)" }}>
            {lang === "hi" ? "आपकी गोपनीयता हमारी प्राथमिकता है" : "Your privacy is our priority"}
          </p>
        </div>

        {/* Sections */}
        <div style={{ display: "flex", flexDirection: "column", gap: "0.9rem" }}>
          {sections.map((s, i) => (
            <div
              key={i}
              style={{
                background: "rgba(255,255,255,0.05)",
                border: "1px solid rgba(255,255,255,0.09)",
                borderRadius: "0.9rem",
                padding: "1.1rem 1.2rem",
                backdropFilter: "blur(14px)",
              }}
            >
              <h2
                style={{
                  fontSize: "0.9rem",
                  fontWeight: 700,
                  color: "#fdbb2d",
                  marginBottom: "0.6rem",
                  letterSpacing: "0.01em",
                }}
              >
                {s.title}
              </h2>
              <p
                style={{
                  fontSize: "0.82rem",
                  color: "rgba(255,255,255,0.72)",
                  lineHeight: 1.75,
                  whiteSpace: "pre-line",
                  userSelect: "text",
                  WebkitUserSelect: "text",
                }}
              >
                {s.body}
              </p>
            </div>
          ))}
        </div>

        {/* Footer note */}
        <div
          style={{
            textAlign: "center",
            marginTop: "1.5rem",
            fontSize: "0.72rem",
            color: "rgba(255,255,255,0.3)",
          }}
        >
          © 2025 Raindear. {lang === "hi" ? "सर्वाधिकार सुरक्षित।" : "All rights reserved."}
        </div>

      </div>
    </div>
  );
}
