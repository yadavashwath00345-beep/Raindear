import { useState } from "react";

type GameCategory = "puzzle" | "trivia" | "action" | "word" | "board" | "sports" | "arcade" | "card" | "strategy" | "creative";

interface GameItem {
  id: string;
  name: string;
  emoji: string;
  description: string;
  color: string;
  category: GameCategory;
}

const GAME_CATEGORIES: { id: GameCategory; label: string }[] = [
  { id: "trivia",   label: "🧠 Trivia" },
  { id: "puzzle",   label: "🧩 Puzzle" },
  { id: "word",     label: "📝 Word" },
  { id: "arcade",   label: "🕹️ Arcade" },
  { id: "board",    label: "🎲 Board" },
  { id: "card",     label: "🃏 Card" },
  { id: "sports",   label: "⚽ Sports" },
  { id: "action",   label: "🔥 Action" },
  { id: "strategy", label: "♟️ Strategy" },
  { id: "creative", label: "🎨 Creative" },
];

const ALL_GAMES: GameItem[] = [
  // Trivia
  { id: "t01", name: "Bollywood Quiz",       emoji: "🎬", description: "Test your Bollywood knowledge",      color: "#b21f1f",  category: "trivia" },
  { id: "t02", name: "India GK Master",      emoji: "🇮🇳", description: "General knowledge of India",       color: "#ff6600",  category: "trivia" },
  { id: "t03", name: "Science Quiz",         emoji: "🔬", description: "Physics, chemistry & biology",      color: "#4f46e5",  category: "trivia" },
  { id: "t04", name: "Sports Trivia",        emoji: "🏅", description: "World sports & cricket facts",      color: "#047857",  category: "trivia" },
  { id: "t05", name: "History Master",       emoji: "📜", description: "World & Indian history",            color: "#92400e",  category: "trivia" },
  { id: "t06", name: "Geography Quiz",       emoji: "🌍", description: "Capitals, flags & maps",            color: "#0891b2",  category: "trivia" },
  { id: "t07", name: "Tech Quiz",            emoji: "💻", description: "Technology & innovation",           color: "#7c3aed",  category: "trivia" },
  { id: "t08", name: "Filmy Dialogues",      emoji: "🎭", description: "Guess the movie dialogue",          color: "#d97706",  category: "trivia" },
  { id: "t09", name: "Music Trivia",         emoji: "🎵", description: "Bollywood & world music",           color: "#9d174d",  category: "trivia" },
  { id: "t10", name: "Space Quiz",           emoji: "🚀", description: "Planets, stars & universe",         color: "#1d4ed8",  category: "trivia" },
  { id: "t11", name: "Food Quiz",            emoji: "🍜", description: "Indian & world cuisine",            color: "#d97706",  category: "trivia" },
  { id: "t12", name: "Animal Kingdom",       emoji: "🦁", description: "Facts about wild animals",          color: "#047857",  category: "trivia" },
  // Puzzle
  { id: "p01", name: "Sliding Tiles",        emoji: "🟩", description: "Classic 15-tile sliding puzzle",   color: "#4f46e5",  category: "puzzle" },
  { id: "p02", name: "Jigsaw Master",        emoji: "🧩", description: "Solve picture jigsaw puzzles",     color: "#7c3aed",  category: "puzzle" },
  { id: "p03", name: "Sudoku",               emoji: "🔢", description: "Classic number grid puzzle",       color: "#0891b2",  category: "puzzle" },
  { id: "p04", name: "Memory Match",         emoji: "🃏", description: "Flip & match card pairs",          color: "#047857",  category: "puzzle" },
  { id: "p05", name: "Maze Runner",          emoji: "🌀", description: "Navigate through complex mazes",   color: "#b21f1f",  category: "puzzle" },
  { id: "p06", name: "Light Puzzle",         emoji: "💡", description: "Connect light beams to bulbs",     color: "#d97706",  category: "puzzle" },
  { id: "p07", name: "Color Match",          emoji: "🎨", description: "Match colors before time runs out", color: "#9d174d", category: "puzzle" },
  { id: "p08", name: "Block Builder",        emoji: "🏗️", description: "Stack blocks without falling",     color: "#92400e",  category: "puzzle" },
  { id: "p09", name: "Nonogram",             emoji: "⬛", description: "Grid-based picture deduction",    color: "#374151",  category: "puzzle" },
  { id: "p10", name: "Rope Rescue",          emoji: "🪢", description: "Untangle the rope knots",          color: "#4f46e5",  category: "puzzle" },
  { id: "p11", name: "Water Sort",           emoji: "🧪", description: "Sort colored water into tubes",    color: "#0891b2",  category: "puzzle" },
  { id: "p12", name: "Flow Connect",         emoji: "🔗", description: "Connect matching dots on grid",    color: "#7c3aed",  category: "puzzle" },
  // Word
  { id: "w01", name: "Shayari Typing",       emoji: "✍️", description: "Type shayari accurately & fast",  color: "#b21f1f",  category: "word" },
  { id: "w02", name: "Anagram Blast",        emoji: "🔤", description: "Unscramble the jumbled words",     color: "#4f46e5",  category: "word" },
  { id: "w03", name: "Word Search",          emoji: "🔍", description: "Find hidden words in the grid",    color: "#047857",  category: "word" },
  { id: "w04", name: "Crossword Hindi",      emoji: "📰", description: "Hindi crossword puzzle",           color: "#ff6600",  category: "word" },
  { id: "w05", name: "Wordle Hindi",         emoji: "🟨", description: "Guess the 5-letter Hindi word",   color: "#d97706",  category: "word" },
  { id: "w06", name: "Rhyme Time",           emoji: "🎶", description: "Complete the shayari rhymes",      color: "#9d174d",  category: "word" },
  { id: "w07", name: "Abbreviation Quiz",    emoji: "🔡", description: "What does that abbreviation mean?", color: "#0891b2", category: "word" },
  { id: "w08", name: "Tongue Twisters",      emoji: "👅", description: "Hindi tongue twister challenges",  color: "#7c3aed",  category: "word" },
  { id: "w09", name: "Dictionary Duel",      emoji: "📚", description: "Define words before the timer",    color: "#374151",  category: "word" },
  { id: "w10", name: "Proverb Master",       emoji: "🗣️", description: "Complete Indian proverbs",        color: "#92400e",  category: "word" },
  { id: "w11", name: "Spell Champion",       emoji: "✅", description: "Spelling bee with Hindi words",    color: "#047857",  category: "word" },
  { id: "w12", name: "Story Builder",        emoji: "📖", description: "Collaborative story creation",     color: "#b21f1f",  category: "word" },
  // Arcade
  { id: "a01", name: "Raindear Snake",       emoji: "🐍", description: "Classic snake with a twist",       color: "#047857",  category: "arcade" },
  { id: "a02", name: "Flappy Bird Desi",     emoji: "🦅", description: "Indian eagle dodges obstacles",    color: "#ff6600",  category: "arcade" },
  { id: "a03", name: "Bubble Pop",           emoji: "🫧", description: "Pop bubbles before they overflow", color: "#0891b2",  category: "arcade" },
  { id: "a04", name: "Space Shooter",        emoji: "👾", description: "Shoot alien invaders",             color: "#1d4ed8",  category: "arcade" },
  { id: "a05", name: "Coin Rush",            emoji: "🪙", description: "Collect coins, dodge traps",       color: "#d97706",  category: "arcade" },
  { id: "a06", name: "Ball Bounce",          emoji: "🎱", description: "Bounce ball to clear bricks",      color: "#4f46e5",  category: "arcade" },
  { id: "a07", name: "Endless Runner",       emoji: "🏃", description: "Run and jump obstacles forever",   color: "#b21f1f",  category: "arcade" },
  { id: "a08", name: "Fruit Slice",          emoji: "🍉", description: "Slice the fruits with a swipe",    color: "#047857",  category: "arcade" },
  { id: "a09", name: "Tower Stack",          emoji: "🗼", description: "Stack blocks as high as possible", color: "#92400e",  category: "arcade" },
  { id: "a10", name: "Tap Tap Dash",         emoji: "⚡", description: "Tap to change lanes, don't crash", color: "#7c3aed", category: "arcade" },
  { id: "a11", name: "Pinball Classic",      emoji: "🎯", description: "Retro-style pinball machine",      color: "#d97706",  category: "arcade" },
  { id: "a12", name: "Balloon Pop",          emoji: "🎈", description: "Pop as many balloons as you can",  color: "#9d174d",  category: "arcade" },
  // Board
  { id: "b01", name: "Digital Ludo",         emoji: "🎲", description: "Classic 4-player Ludo",            color: "#d97706",  category: "board" },
  { id: "b02", name: "Snakes & Ladders",     emoji: "🐍", description: "Traditional Saanp-Seedi",          color: "#047857",  category: "board" },
  { id: "b03", name: "Carrom Classic",       emoji: "🎯", description: "Digital carrom board",             color: "#92400e",  category: "board" },
  { id: "b04", name: "Checkers",             emoji: "⬛", description: "Classic draughts / checkers",     color: "#374151",  category: "board" },
  { id: "b05", name: "Battleship",           emoji: "⚓", description: "Sink the enemy fleet",            color: "#1d4ed8",  category: "board" },
  { id: "b06", name: "Scrabble Lite",        emoji: "🔤", description: "Word-building board game",         color: "#4f46e5",  category: "board" },
  { id: "b07", name: "Connect Four",         emoji: "🔵", description: "Classic 4-in-a-row game",         color: "#d97706",  category: "board" },
  { id: "b08", name: "Tic Tac Toe XL",       emoji: "❌", description: "5×5 tic-tac-toe challenge",       color: "#b21f1f",  category: "board" },
  { id: "b09", name: "Dices of Doom",        emoji: "🎲", description: "Risk-style dice territory game",   color: "#ff6600",  category: "board" },
  { id: "b10", name: "Mancala",              emoji: "🪨", description: "Ancient African strategy game",    color: "#92400e",  category: "board" },
  { id: "b11", name: "Othello / Reversi",    emoji: "⚫", description: "Flip opponent discs to win",      color: "#374151",  category: "board" },
  { id: "b12", name: "Blokus Lite",          emoji: "🟦", description: "Place pieces to block your rival", color: "#7c3aed", category: "board" },
  // Card
  { id: "c01", name: "Teen Patti",           emoji: "🃏", description: "Classic Indian 3-card game",       color: "#b21f1f",  category: "card" },
  { id: "c02", name: "Solitaire",            emoji: "🎴", description: "Classic card solitaire",           color: "#374151",  category: "card" },
  { id: "c03", name: "Rummy Lite",           emoji: "🎲", description: "Indian Rummy card game",           color: "#047857",  category: "card" },
  { id: "c04", name: "Memory Pairs",         emoji: "🃏", description: "Classic memory card pairs",        color: "#4f46e5",  category: "card" },
  { id: "c05", name: "Snap!",               emoji: "👏", description: "Tap snap when cards match",        color: "#d97706",  category: "card" },
  { id: "c06", name: "War",                  emoji: "⚔️", description: "High card wins the round",        color: "#b21f1f",  category: "card" },
  { id: "c07", name: "Black Jack Lite",      emoji: "🃏", description: "Get to 21 without busting",        color: "#1d4ed8",  category: "card" },
  { id: "c08", name: "Go Fish",              emoji: "🐟", description: "Classic children's card game",     color: "#0891b2",  category: "card" },
  { id: "c09", name: "Bluff",               emoji: "😏", description: "Lie about your cards & win",       color: "#9d174d",  category: "card" },
  { id: "c10", name: "Old Maid",             emoji: "👴", description: "Don't get left with the Old Maid", color: "#92400e", category: "card" },
  // Sports
  { id: "s01", name: "Cricket Tap",          emoji: "🏏", description: "Tap to hit, score max runs",       color: "#047857",  category: "sports" },
  { id: "s02", name: "Penalty Shootout",     emoji: "⚽", description: "Score goals in the shootout",      color: "#0891b2",  category: "sports" },
  { id: "s03", name: "Basket Ball Dunk",     emoji: "🏀", description: "Tilt and score baskets",           color: "#d97706",  category: "sports" },
  { id: "s04", name: "Table Tennis",         emoji: "🏓", description: "Fast-paced ping-pong action",      color: "#4f46e5",  category: "sports" },
  { id: "s05", name: "Archery Master",       emoji: "🏹", description: "Hit the bullseye every time",      color: "#b21f1f",  category: "sports" },
  { id: "s06", name: "Golf Lite",            emoji: "⛳", description: "Mini golf in 18 holes",            color: "#047857",  category: "sports" },
  { id: "s07", name: "Badminton Smash",      emoji: "🏸", description: "Smash the birdie over the net",    color: "#7c3aed",  category: "sports" },
  { id: "s08", name: "Tennis Ace",           emoji: "🎾", description: "Serve and volley champion",        color: "#d97706",  category: "sports" },
  // Action
  { id: "ac1", name: "Ninja Rush",           emoji: "🥷", description: "Slash enemies as a ninja",         color: "#374151",  category: "action" },
  { id: "ac2", name: "Zombie Blaster",       emoji: "🧟", description: "Shoot zombies before they reach",  color: "#b21f1f",  category: "action" },
  { id: "ac3", name: "Tank Battle",          emoji: "🪖", description: "Destroy enemy tanks on map",       color: "#92400e",  category: "action" },
  { id: "ac4", name: "Sky Fighter",          emoji: "✈️", description: "Dogfight above the clouds",       color: "#1d4ed8",  category: "action" },
  { id: "ac5", name: "Dino Run",             emoji: "🦖", description: "Offline dino style runner",        color: "#047857",  category: "action" },
  { id: "ac6", name: "Castle Defense",       emoji: "🏰", description: "Protect your castle from invaders", color: "#9d174d", category: "action" },
  { id: "ac7", name: "Stickman Fight",       emoji: "🥊", description: "Stickman vs stickman battles",     color: "#b21f1f",  category: "action" },
  { id: "ac8", name: "Asteroid Dodge",       emoji: "☄️", description: "Dodge asteroids in deep space",   color: "#1d4ed8",  category: "action" },
  // Strategy
  { id: "st1", name: "Chess Classic",        emoji: "♟️", description: "Full chess vs AI",                color: "#374151",  category: "strategy" },
  { id: "st2", name: "Tower Defense",        emoji: "🗼", description: "Build towers, stop enemies",       color: "#047857",  category: "strategy" },
  { id: "st3", name: "2048",                 emoji: "🔢", description: "Merge tiles to reach 2048",        color: "#d97706",  category: "strategy" },
  { id: "st4", name: "Minesweeper",          emoji: "💣", description: "Clear the minefield safely",       color: "#9d174d",  category: "strategy" },
  { id: "st5", name: "City Builder",         emoji: "🏙️", description: "Build your ideal city",           color: "#0891b2",  category: "strategy" },
  { id: "st6", name: "Farm Manager",         emoji: "🌾", description: "Grow crops and manage a farm",    color: "#047857",  category: "strategy" },
  { id: "st7", name: "Quiz Battle",          emoji: "⚔️", description: "Answer trivia to defeat rivals",  color: "#4f46e5",  category: "strategy" },
  { id: "st8", name: "Stock Market Game",    emoji: "📈", description: "Buy low, sell high",              color: "#b21f1f",  category: "strategy" },
  // Creative
  { id: "cr1", name: "Pixel Art",            emoji: "🖼️", description: "Create pixel art masterpieces",   color: "#7c3aed",  category: "creative" },
  { id: "cr2", name: "Music Maker",          emoji: "🎹", description: "Create beats with a DJ pad",       color: "#9d174d",  category: "creative" },
  { id: "cr3", name: "Draw & Guess",         emoji: "✏️", description: "Draw a word, others guess",       color: "#d97706",  category: "creative" },
  { id: "cr4", name: "Mandala Design",       emoji: "🌸", description: "Create intricate mandalas",        color: "#4f46e5",  category: "creative" },
  { id: "cr5", name: "Shayari Generator",    emoji: "✍️", description: "AI-assisted shayari creation",    color: "#b21f1f",  category: "creative" },
  { id: "cr6", name: "Avatar Creator",       emoji: "👤", description: "Build your custom Raindear avatar", color: "#0891b2", category: "creative" },
  { id: "cr7", name: "Photo Filter",         emoji: "📸", description: "Add Raindear sunset filters",      color: "#ff6600",  category: "creative" },
  { id: "cr8", name: "Coloring Book",        emoji: "🖍️", description: "Color Indian motifs & patterns",  color: "#d97706",  category: "creative" },
];

export default function Games() {
  const [activeCategory, setActiveCategory] = useState<GameCategory>("trivia");
  const filtered = ALL_GAMES.filter((g) => g.category === activeCategory);

  const totalGames = ALL_GAMES.length;

  return (
    <div className="page-enter" data-testid="page-games">
      <div className="page-pad">

        {/* Hero */}
        <div className="hero-banner shimmer" style={{ marginBottom: "1.1rem" }}>
          <div className="hero-title" style={{ fontFamily: "'Poppins', sans-serif", fontSize: "1.4rem", fontWeight: 800 }}>
            🎮 Games Shelf
          </div>
          <p className="hero-subtitle">
            {totalGames}+ games planned across 10 categories — uploading logic one by one
          </p>
        </div>

        {/* Stats */}
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(3, 1fr)",
            gap: "0.6rem",
            marginBottom: "1.1rem",
          }}
        >
          {[
            { label: "Total Games", value: `${totalGames}+` },
            { label: "Categories",  value: "10" },
            { label: "Status",      value: "Soon" },
          ].map((s) => (
            <div key={s.label} className="glass-card" style={{ padding: "0.75rem", textAlign: "center" }}>
              <div style={{ fontSize: "1.15rem", fontWeight: 800, color: "#fdbb2d" }}>{s.value}</div>
              <div style={{ fontSize: "0.65rem", color: "rgba(255,255,255,0.5)", fontWeight: 500, marginTop: "2px" }}>{s.label}</div>
            </div>
          ))}
        </div>

        {/* Category Tabs */}
        <div className="cat-tabs" style={{ marginBottom: "1rem" }}>
          {GAME_CATEGORIES.map((cat) => (
            <button
              key={cat.id}
              className={`cat-tab ${activeCategory === cat.id ? "active" : ""}`}
              onClick={() => setActiveCategory(cat.id)}
              data-testid={`game-cat-${cat.id}`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Games Grid */}
        <div className="games-grid">
          {filtered.map((game) => (
            <div
              key={game.id}
              className="game-card"
              data-testid={`game-card-${game.id}`}
              style={{ position: "relative", overflow: "hidden" }}
            >
              <div
                style={{
                  position: "absolute",
                  top: 0, left: 0, right: 0,
                  height: "3px",
                  background: game.color,
                  borderRadius: "0.1rem 0.1rem 0 0",
                  opacity: 0.75,
                }}
              />
              <div style={{ fontSize: "1.9rem", marginBottom: "0.35rem" }}>{game.emoji}</div>
              <div
                style={{
                  fontSize: "0.75rem",
                  fontWeight: 700,
                  color: "#fff",
                  marginBottom: "0.18rem",
                  lineHeight: 1.2,
                  textAlign: "center",
                }}
              >
                {game.name}
              </div>
              <div style={{ fontSize: "0.6rem", color: "rgba(255,255,255,0.42)", lineHeight: 1.3, textAlign: "center" }}>
                {game.description}
              </div>
              <div className="badge badge-gold" style={{ marginTop: "0.5rem", fontSize: "0.55rem" }}>
                Coming Soon
              </div>
            </div>
          ))}
        </div>

        {/* Upload note */}
        <div
          className="glass-card"
          style={{ padding: "1rem", marginTop: "1.25rem", textAlign: "center", borderColor: "rgba(253,187,45,0.2)" }}
        >
          <div style={{ fontSize: "0.8rem", color: "rgba(255,255,255,0.6)", lineHeight: 1.6 }}>
            📁 Upload game logic to{" "}
            <code
              style={{
                background: "rgba(253,187,45,0.12)",
                color: "#fdbb2d",
                padding: "0.1rem 0.4rem",
                borderRadius: "0.3rem",
                fontSize: "0.72rem",
                fontFamily: "monospace",
              }}
            >
              modules/games/
            </code>{" "}
            to activate each slot
          </div>
        </div>
      </div>
    </div>
  );
}
