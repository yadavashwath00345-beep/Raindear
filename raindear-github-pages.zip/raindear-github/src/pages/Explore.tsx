import { useState } from "react";
import VideoFacade from "@/components/VideoFacade";

type Category = "shayari" | "horror" | "fashion" | "style" | "news";

interface VideoItem {
  id: string;
  title: string;
  badge?: string;
}

const CATEGORIES: { id: Category; label: string }[] = [
  { id: "shayari", label: "💫 Shayari" },
  { id: "horror",  label: "👻 Horror Story" },
  { id: "fashion", label: "👗 Fashion" },
  { id: "style",   label: "✨ Style" },
  { id: "news",    label: "📺 News" },
];

const VIDEOS: Record<Category, VideoItem[]> = {
  shayari: [
    { id: "5qap5aO4i9A", title: "Best Sad Shayari 2024 | Dil Ko Chu Lene Wali" },
    { id: "d-I2g3a1-Og", title: "Love Shayari | Mohabbat Ki Zubaan" },
    { id: "6WoNsuPE39c", title: "Romantic Shayari | Dil Ki Baat" },
    { id: "YQHsXMglC9A", title: "Breakup Shayari | Judai Ka Dard" },
    { id: "DHvQ0RCiIMs", title: "Motivational Shayari | Hausla Rakh" },
    { id: "Iu_eUK0EMHY", title: "Dard Bhari Shayari | Aankhon Se Baat" },
    { id: "tgbNymZ7vqY", title: "Two Lines Shayari | Short & Beautiful" },
    { id: "VOgFZfRVfPU", title: "Friendship Shayari | Yaari Ka Rang" },
  ],
  horror: [
    { id: "sGbxmsDFVnE", title: "Real Horror Story | Raat Ki Kahani" },
    { id: "sBE7SLqX1ZI", title: "Haunted Village Story | Bhutiya Gaon" },
    { id: "f4Mc-NYPHaQ", title: "Horror Story in Hindi | Andheri Raat" },
    { id: "mP4ufAo-RDM", title: "Ghost Story | Bhool Bhulaiya" },
    { id: "qEXv-rVWAu8", title: "Scary Experience | True Horror Tale" },
    { id: "ktvTqknDobU", title: "Dark Night Horror | Bhoot Ki Kahani" },
    { id: "JZEjUaJMf_A", title: "Horror Story | Purani Haveli" },
    { id: "v7AYKMP6rOE", title: "Supernatural Story | Jadui Janwar" },
  ],
  fashion: [
    { id: "woGiEILfFww", title: "Bollywood Inspired Outfit Ideas 2024" },
    { id: "nUGCDiJxTI4", title: "Traditional Indian Fashion Trends" },
    { id: "FHdpH3EYEQ0", title: "Street Style Fashion India 2024" },
    { id: "YkgkThdzX-8", title: "Saree Draping Styles | Modern Look" },
    { id: "8NpB_MgKgkI", title: "Summer Outfit Ideas | Indo-Western" },
    { id: "2Vv-BfVoq4g", title: "Lehenga Styles 2024 | Bridal Edition" },
    { id: "wMTeOKMRPkY", title: "Budget Fashion Tips | College Style" },
    { id: "YODoFLn2jeU", title: "Men's Fashion Trends India 2024" },
  ],
  style: [
    { id: "hvn0yRVsN0s", title: "Hair Styling Tutorial | Indian Hairstyles" },
    { id: "ZTiLIbRaVpQ", title: "Makeup Tips for Beginners | Natural Look" },
    { id: "X2Lp9T9HKQI", title: "Skincare Routine | Glowing Skin Tips" },
    { id: "wNbFEWoWpvA", title: "Nail Art Ideas | DIY at Home" },
    { id: "EFiOB3Sxkz4", title: "Minimalist Style Guide | Less is More" },
    { id: "SRiP4hI4KPM", title: "Accessories Tips | Complete Your Look" },
    { id: "BPjHqKPKd2A", title: "Men's Grooming Guide | Style Upgrade" },
    { id: "Uazn9o16bKQ", title: "Color Matching Outfit | Style Basics" },
  ],
  news: [
    { id: "coYw-eVU0Ks", title: "Aaj Tak Live | Breaking News Hindi", badge: "LIVE" },
    { id: "hCuMWrfXG4E", title: "NDTV India | Latest News Today", badge: "LIVE" },
    { id: "Fzz4hHJBPx0", title: "ABP News | Top Stories Today" },
    { id: "T0xENknE46o", title: "India TV | Aaj Ki Taza Khabar" },
    { id: "8Y3pS-JXJQM", title: "Zee News | Mukhya Samachar" },
    { id: "DLPRgIR1KOQ", title: "Republic Bharat | Breaking News" },
    { id: "6NlCRHEFBT0", title: "News18 India | Prime Time" },
    { id: "mCxBSj8JNSQ", title: "DD News | National Headlines" },
  ],
};

export default function Explore() {
  const [activeCategory, setActiveCategory] = useState<Category>("shayari");
  const videos = VIDEOS[activeCategory];

  const catDescriptions: Record<Category, string> = {
    shayari:  "Curated Shayari videos — sad, love, motivational & more",
    horror:   "Spine-chilling horror stories in Hindi — watch with lights on!",
    fashion:  "Bollywood-inspired fashion, outfits & trending styles",
    style:    "Hair, makeup, skincare & grooming guides",
    news:     "Live Hindi news from India's top channels",
  };

  return (
    <div className="page-enter" data-testid="page-explore">
      <div className="page-pad">

        {/* Hero Banner */}
        <div className="hero-banner shimmer" style={{ marginBottom: "1.1rem" }}>
          <div className="hero-title">Explore Raindear</div>
          <p className="hero-subtitle">{catDescriptions[activeCategory]}</p>
        </div>

        {/* Category Tabs */}
        <div className="cat-tabs" style={{ marginBottom: "1rem" }}>
          {CATEGORIES.map((cat) => (
            <button
              key={cat.id}
              className={`cat-tab ${activeCategory === cat.id ? "active" : ""}`}
              onClick={() => setActiveCategory(cat.id)}
              data-testid={`cat-tab-${cat.id}`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Video Grid */}
        <div className="video-grid">
          {videos.map((v) => (
            <VideoFacade
              key={v.id}
              videoId={v.id}
              title={v.title}
              badge={v.badge}
            />
          ))}
        </div>

        <p
          style={{
            textAlign: "center",
            fontSize: "0.72rem",
            color: "rgba(255,255,255,0.28)",
            marginTop: "1.5rem",
          }}
        >
          Tap any video to start watching • Swipe tabs to explore more
        </p>
      </div>
    </div>
  );
}
