import { useState, useCallback } from "react";

type ShayariCategory = "sad" | "love" | "funny" | "motivational" | "friendship";

const CATEGORIES: { id: ShayariCategory; label: string }[] = [
  { id: "love",         label: "❤️ Love" },
  { id: "sad",          label: "💔 Sad" },
  { id: "motivational", label: "💪 Motivational" },
  { id: "funny",        label: "😂 Funny" },
  { id: "friendship",   label: "🤝 Friendship" },
];

const SHAYARIS: Record<ShayariCategory, { text: string; author?: string }[]> = {
  love: [
    { text: "Teri aankhon mein kho jaata hoon main,\nHar khwaab mein tujhe hi paata hoon main...", author: "— Raindear" },
    { text: "Mohabbat ki zubaan hoti hai khamoshi,\nTujhse milke mili hai dil ko khushi...", author: "— Anon" },
    { text: "Teri muskaan pe fida hoon main,\nTere pyaar ka diwana hoon main...", author: "— Raindear" },
    { text: "Har raat tere sapne aate hain,\nHar subah tere khayaal jaate hain...", author: "— Anon" },
    { text: "Tujhse pehle thi zindagi adhuri si,\nAb tere sang lagi hai pyaari si...", author: "— Raindear" },
    { text: "Ishq mein doob ke aisa lagta hai,\nJaise har khushi mujhko milti hai...", author: "— Anon" },
  ],
  sad: [
    { text: "Dard mein bhi muskurana seekh liya humne,\nZindagi ne bahut kuch sikhaya hai humein...", author: "— Raindear" },
    { text: "Teri yaad aati hai jab bhi raat hoti hai,\nDil pe teri tasveer bann jaati hai...", author: "— Anon" },
    { text: "Khamoshi meri zubaan ban gayi hai,\nDard hi ab meri pehchaan ban gayi hai...", author: "— Raindear" },
    { text: "Jo waqt tha woh guzar gaya,\nDil mera toot ke bikhar gaya...", author: "— Anon" },
    { text: "Aankhon mein teri yaad liye phirta hoon,\nHar mod pe tujhe dhoondta hoon...", author: "— Raindear" },
    { text: "Rona chahta hoon par aansu kahan hain,\nDil mein dard hai par aawaaz kahan hai...", author: "— Anon" },
  ],
  motivational: [
    { text: "Girte hain shehsawar hi maidan-e-jung mein,\nWoh tifl kya girenge jo ghutno ke bal chale...", author: "— Akbar Allahabadi" },
    { text: "Mushkilon se nahi ghabhraate hain hum,\nMushkilon ko hi apna andaaz banaate hain...", author: "— Raindear" },
    { text: "Haar se nahi darr, haar ke baad uthna seekh,\nJo baar baar uthta hai woh bhi jeeta hai...", author: "— Raindear" },
    { text: "Sapne woh nahi jo neend mein aayein,\nSapne woh hain jo neend na aane dein...", author: "— A.P.J. Abdul Kalam" },
    { text: "Zindagi mein tab kuch milta hai,\nJab hum kuch karne ka hausla rakhte hain...", author: "— Raindear" },
    { text: "Toofan se daro mat, toofan ke liye taiyaar raho,\nYahi hai zindagi ka asli karaar...", author: "— Anon" },
  ],
  funny: [
    { text: "Ghar wale keh rahe hain padh lo,\nHum keh rahe hain — kal se pakka!", author: "— Har Student" },
    { text: "Dil ne kaha diet karo,\nPet ne kaha — acha joke tha!", author: "— Raindear" },
    { text: "Neend nahi aati raat ko humein,\nDin mein sone se kya karna humein!", author: "— Anon" },
    { text: "Exam mein likh diya — 'Abhi yaad nahi',\nTeacher ne likha — 'Abhi marks nahi'!", author: "— Topper" },
    { text: "Mobile haath mein raho toh,\nMaa ki awaaz rocket jaisi lagti hai!", author: "— Raindear" },
    { text: "Dost ne poocha — tu theek hai?\nMainne kaha — haan, abhi WIFI hai!", author: "— Anon" },
  ],
  friendship: [
    { text: "Dost woh hote hain jo dard baat lein,\nJo khushiyon mein saath haan mein maan lein...", author: "— Raindear" },
    { text: "Yaari mein koi hisab nahi hota,\nSach ki dosti mein koi andaaz nahi hota...", author: "— Anon" },
    { text: "Tere jaisa dost milna mushkil hai,\nTere bina jeena dil ke liye mushkil hai...", author: "— Raindear" },
    { text: "Dosti ka rishta dil se hota hai,\nYeh rishta khoon se bhi gehra hota hai...", author: "— Anon" },
    { text: "Doston ke saath waqt guzara bahut,\nAb bhi yaad hai woh pal bahut...", author: "— Raindear" },
    { text: "Achha dost woh hai jo galat raaston pe rokein,\nJo sahi waqt pe sahi baat bolein...", author: "— Anon" },
  ],
};

function ShayariCard({ shayari, index }: { shayari: { text: string; author?: string }; index: number }) {
  const [copied, setCopied] = useState(false);

  const handleCopy = useCallback(() => {
    const fullText = shayari.author
      ? `${shayari.text}\n${shayari.author}`
      : shayari.text;
    navigator.clipboard?.writeText(fullText).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }, [shayari]);

  return (
    <div
      className="shayari-card"
      data-testid={`shayari-card-${index}`}
    >
      <div style={{ whiteSpace: "pre-line", paddingTop: "0.4rem" }}>
        {shayari.text}
      </div>
      {shayari.author && (
        <div className="shayari-card-author">{shayari.author}</div>
      )}
      <button
        className={`copy-btn ${copied ? "copied" : ""}`}
        onClick={handleCopy}
        data-testid={`copy-shayari-${index}`}
        aria-label="Copy shayari"
      >
        {copied ? "✓ Copied" : "Copy"}
      </button>
    </div>
  );
}

export default function Shayari() {
  const [activeCategory, setActiveCategory] = useState<ShayariCategory>("love");
  const shayaris = SHAYARIS[activeCategory];

  return (
    <div className="page-enter" data-testid="page-shayari">
      <div className="page-pad">

        {/* Hero */}
        <div
          className="hero-banner shimmer"
          style={{
            marginBottom: "1.1rem",
            background: "linear-gradient(135deg, rgba(178,31,31,0.55) 0%, rgba(26,42,108,0.75) 60%, rgba(253,187,45,0.1) 100%)",
            textAlign: "center",
          }}
        >
          <div className="hero-title">✍️ Shayari</div>
          <p className="hero-subtitle">Dil ki baat, lafzon mein — tap Copy to share</p>
        </div>

        {/* Category Tabs */}
        <div className="cat-tabs" style={{ marginBottom: "1.25rem" }}>
          {CATEGORIES.map((cat) => (
            <button
              key={cat.id}
              className={`cat-tab ${activeCategory === cat.id ? "active" : ""}`}
              onClick={() => setActiveCategory(cat.id)}
              data-testid={`shayari-cat-${cat.id}`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Shayari Cards */}
        <div style={{ display: "flex", flexDirection: "column", gap: "1rem" }}>
          {shayaris.map((s, i) => (
            <ShayariCard key={`${activeCategory}-${i}`} shayari={s} index={i} />
          ))}
        </div>

        <div
          className="glass-card"
          style={{
            padding: "1rem",
            marginTop: "1.25rem",
            textAlign: "center",
            borderColor: "rgba(253,187,45,0.2)",
          }}
        >
          <div style={{ fontSize: "0.8rem", color: "rgba(255,255,255,0.55)", lineHeight: 1.6 }}>
            ✨ More shayari coming — add yours to{" "}
            <code
              style={{
                background: "rgba(253,187,45,0.12)",
                color: "#fdbb2d",
                padding: "0.1rem 0.4rem",
                borderRadius: "0.3rem",
                fontSize: "0.72rem",
                fontFamily: "monospace",
              }}
            >
              modules/shayari/
            </code>
          </div>
        </div>
      </div>
    </div>
  );
}
