import { useState } from "react";
import VideoFacade from "@/components/VideoFacade";

type NatureCategory = "forests" | "ocean" | "mountains" | "birds" | "rain" | "sunset" | "animals" | "rivers";

interface VideoItem {
  id: string;
  title: string;
  badge?: string;
}

const CATEGORIES: { id: NatureCategory; label: string }[] = [
  { id: "forests",   label: "🌲 Forests" },
  { id: "ocean",     label: "🌊 Ocean" },
  { id: "mountains", label: "🏔️ Mountains" },
  { id: "birds",     label: "🦅 Birds" },
  { id: "rain",      label: "🌧️ Rain" },
  { id: "sunset",    label: "🌅 Sunsets" },
  { id: "animals",   label: "🐾 Animals" },
  { id: "rivers",    label: "🏞️ Rivers" },
];

const VIDEOS: Record<NatureCategory, VideoItem[]> = {
  forests: [
    { id: "eKmBMOCEsUQ", title: "Deep Forest Sounds | 8 Hours Rain & Birds" },
    { id: "ry8SoFFzV9U", title: "Magical Forest | Morning Birdsong" },
    { id: "sGkh1W5cbH4", title: "Forest Rain | Relaxing Nature Sounds" },
    { id: "xNN7iTA57jM", title: "Enchanted Forest Walk | ASMR Nature" },
    { id: "bP9gMpl1gyQ", title: "Amazon Rainforest | Wild Nature 4K" },
    { id: "Y7DFT6eoUhE", title: "Bamboo Forest | Peaceful Meditation" },
    { id: "jCr_r4TJ_MU", title: "Autumn Forest | Falling Leaves ASMR" },
    { id: "mPZkdNFkNps", title: "Pine Forest | Wind Through Trees" },
  ],
  ocean: [
    { id: "RDZK_GbH8oI", title: "Ocean Waves | Calm Beach ASMR 4K" },
    { id: "bn9F19Hi1nM", title: "Deep Ocean | Underwater Documentary" },
    { id: "FjHGZj2IjBk", title: "Tropical Reef | Colorful Marine Life" },
    { id: "V1bFr2SWP1I", title: "Pacific Ocean | Sunset Waves" },
    { id: "OdIJ2x3nxzQ", title: "Stormy Sea | Powerful Ocean Waves" },
    { id: "9Q_gQfGAFAI", title: "Beach Rain | Relaxing Coastal Sounds" },
    { id: "e3vbB4WBVss", title: "Whale Songs | Deep Ocean ASMR" },
    { id: "q76bMs-NwRk", title: "Blue Lagoon | Crystal Clear Water" },
  ],
  mountains: [
    { id: "FfKmwPmJwkA", title: "Himalayan Peaks | India's Roof 4K" },
    { id: "3xBMsHlthJ8", title: "Mountain Sunrise | Time Lapse 4K" },
    { id: "yMSc9MarkU0", title: "Swiss Alps | Snow Mountain Walk" },
    { id: "TK9HNkRFCKQ", title: "Rocky Mountains | Wildlife & Peaks" },
    { id: "LiSXxRN5DfU", title: "Misty Mountains | Morning Fog 4K" },
    { id: "e_04ZrNroTo", title: "Himalaya Trek | River & Peaks" },
    { id: "WNcsUNKnbDY", title: "Volcano Eruption | Nature's Power" },
    { id: "G85aHEhZPqc", title: "Night Sky | Mountain Star Timelapse" },
  ],
  birds: [
    { id: "cPpMeJYGGIo", title: "Indian Birds | Peacock, Kingfisher & More" },
    { id: "oNkVPDhDuJo", title: "Eagle in Flight | Slow Motion 4K" },
    { id: "AaasXOZNcqM", title: "Tropical Birds | Amazon Rainforest" },
    { id: "K6C3zO2JMBE", title: "Flamingo Colony | Pink Bird Paradise" },
    { id: "mPdBtBrPNtg", title: "Hummingbird | Slow Motion Wings" },
    { id: "bGKGhBEqFUc", title: "Owls in the Wild | Night Hunters" },
    { id: "MJHOmRqmEpY", title: "Parrot & Macaw | Colorful Birds 4K" },
    { id: "XpBVapbsAGk", title: "Peacock Dance | Beautiful Display" },
  ],
  rain: [
    { id: "q76bMs-NwRk", title: "Heavy Rain ASMR | Sleep & Relax" },
    { id: "nDq6TstdEi8", title: "Monsoon Rain | Indian Village" },
    { id: "Dy-bEoSOeGY", title: "Rain on Window | Cozy Night ASMR" },
    { id: "BOadQihNvdo", title: "Thunderstorm | Powerful Lightning Rain" },
    { id: "9Q_gQfGAFAI", title: "Rain Forest | 8 Hour Nature Sleep" },
    { id: "V1bFr2SWP1I", title: "Beach Rain | Waves & Raindrops" },
    { id: "sGkh1W5cbH4", title: "Forest Rain | Birdsong & Drops" },
    { id: "eKmBMOCEsUQ", title: "Gentle Rain | Study & Focus ASMR" },
  ],
  sunset: [
    { id: "G85aHEhZPqc", title: "Rajasthan Sunset | Desert Dusk 4K" },
    { id: "3xBMsHlthJ8", title: "Ocean Sunset | Golden Hour 4K" },
    { id: "FfKmwPmJwkA", title: "Mountain Sunset | Himalayan Glow" },
    { id: "mPZkdNFkNps", title: "Kerala Sunset | Backwaters Gold" },
    { id: "yMSc9MarkU0", title: "Sunset Time-Lapse | City to Stars" },
    { id: "TK9HNkRFCKQ", title: "African Savanna Sunset | Wild" },
    { id: "e_04ZrNroTo", title: "Goa Sunset | Waves & Orange Sky" },
    { id: "LiSXxRN5DfU", title: "Sunrise to Sunset | Full Day 4K" },
  ],
  animals: [
    { id: "cPpMeJYGGIo", title: "Big Cats | Lions & Tigers in Wild" },
    { id: "oNkVPDhDuJo", title: "Elephant Family | African Savanna" },
    { id: "AaasXOZNcqM", title: "Snow Leopard | Himalayan Ghost Cat" },
    { id: "MJHOmRqmEpY", title: "Wild India | Tiger Reserve 4K" },
    { id: "XpBVapbsAGk", title: "Dolphins | Ocean Play Slow Motion" },
    { id: "bGKGhBEqFUc", title: "Wolf Pack | Northern Wilderness" },
    { id: "K6C3zO2JMBE", title: "Cheetah Run | Fastest Animal" },
    { id: "mPdBtBrPNtg", title: "Baby Animals | Cute Wildlife 4K" },
  ],
  rivers: [
    { id: "nDq6TstdEi8", title: "Ganga Aarti | Haridwar Sacred River" },
    { id: "Dy-bEoSOeGY", title: "Himalayan River | Rushing Glacier Water" },
    { id: "BOadQihNvdo", title: "Amazon River | Jungle & Wildlife" },
    { id: "bn9F19Hi1nM", title: "Kerala Backwaters | Peaceful Waterway" },
    { id: "ry8SoFFzV9U", title: "Waterfall | Tropical Jungle Cascade" },
    { id: "xNN7iTA57jM", title: "River ASMR | Flowing Water Sounds" },
    { id: "bP9gMpl1gyQ", title: "Nile River | Ancient Waterway 4K" },
    { id: "Y7DFT6eoUhE", title: "Valley River | Mountain Stream 4K" },
  ],
};

const NATURE_FACTS = [
  "🌳 A single tree can absorb up to 22 kg of CO₂ per year",
  "🌊 The ocean produces over 50% of Earth's oxygen",
  "🦋 Butterflies taste with their feet",
  "🌧️ A raindrop falls at about 9 km/h",
  "🐘 Elephants are the only animals that can't jump",
  "🌺 There are over 400,000 known plant species on Earth",
];

export default function Nature() {
  const [activeCategory, setActiveCategory] = useState<NatureCategory>("forests");
  const videos = VIDEOS[activeCategory];

  return (
    <div className="page-enter" data-testid="page-nature">
      <div className="page-pad">

        {/* Hero */}
        <div
          className="hero-banner shimmer"
          style={{
            marginBottom: "1.1rem",
            background: "linear-gradient(135deg, rgba(4,78,57,0.7) 0%, rgba(26,42,108,0.65) 60%, rgba(16,110,62,0.3) 100%)",
          }}
        >
          <div className="hero-title" style={{ fontFamily: "'Poppins', sans-serif", fontSize: "1.4rem" }}>
            🌿 Nature Escape
          </div>
          <p className="hero-subtitle">
            Forests, oceans, mountains & wildlife — breathe and unwind
          </p>
          {/* Quick fact ticker */}
          <div
            style={{
              marginTop: "0.75rem",
              padding: "0.4rem 0.75rem",
              background: "rgba(255,255,255,0.07)",
              borderRadius: "0.5rem",
              fontSize: "0.72rem",
              color: "rgba(255,255,255,0.7)",
              borderLeft: "2px solid rgba(74,222,128,0.5)",
            }}
          >
            {NATURE_FACTS[Math.floor(Math.random() * NATURE_FACTS.length)]}
          </div>
        </div>

        {/* Category Tabs */}
        <div className="cat-tabs" style={{ marginBottom: "1rem" }}>
          {CATEGORIES.map((cat) => (
            <button
              key={cat.id}
              className={`cat-tab ${activeCategory === cat.id ? "active" : ""}`}
              onClick={() => setActiveCategory(cat.id)}
              data-testid={`nature-cat-${cat.id}`}
              style={activeCategory === cat.id ? {
                background: "rgba(74,222,128,0.15)",
                borderColor: "rgba(74,222,128,0.4)",
                color: "#4ade80",
              } : {}}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Video Grid */}
        <div className="video-grid">
          {videos.map((v) => (
            <VideoFacade key={v.id} videoId={v.id} title={v.title} badge={v.badge} />
          ))}
        </div>

        {/* Stats row */}
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(3, 1fr)",
            gap: "0.6rem",
            marginTop: "1.25rem",
          }}
        >
          {[
            { label: "Categories", value: "8" },
            { label: "Videos", value: "64" },
            { label: "Hours", value: "∞" },
          ].map((s) => (
            <div key={s.label} className="glass-card" style={{ padding: "0.75rem", textAlign: "center" }}>
              <div style={{ fontSize: "1.2rem", fontWeight: 800, color: "#4ade80" }}>{s.value}</div>
              <div style={{ fontSize: "0.65rem", color: "rgba(255,255,255,0.5)", fontWeight: 500, marginTop: "2px" }}>{s.label}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
