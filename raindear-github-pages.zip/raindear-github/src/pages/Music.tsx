import { useState, useRef } from "react";

interface Track {
  id: string;
  title: string;
  artist: string;
  genre: string;
  youtubeId: string;
  color: string;
}

const TRACKS: Track[] = [
  { id: "1", title: "Lo-Fi Rain Beats",      artist: "Raindear Lounge", genre: "Lo-Fi",     youtubeId: "jfKfPfyJRdk", color: "#4f46e5" },
  { id: "2", title: "Midnight Chill Hop",    artist: "Chill Studio",    genre: "Chill Hop",  youtubeId: "lTRiuFIWV54", color: "#0891b2" },
  { id: "3", title: "Desi Hip Hop Vibes",    artist: "Desi Beats",      genre: "Hip Hop",    youtubeId: "DHvQ0RCiIMs", color: "#b21f1f" },
  { id: "4", title: "Bollywood Chillout",    artist: "BW Remix",        genre: "Bollywood",  youtubeId: "d-I2g3a1-Og", color: "#d97706" },
  { id: "5", title: "Sufi Nights",           artist: "Sufi Soul",       genre: "Sufi",       youtubeId: "6WoNsuPE39c", color: "#7c3aed" },
  { id: "6", title: "Cafe Study Mix",        artist: "Study Beats",     genre: "Lo-Fi",      youtubeId: "5qap5aO4i9A", color: "#047857" },
];

export default function Music() {
  const [playing, setPlaying] = useState<string | null>(null);
  const [activeTrack, setActiveTrack] = useState<Track | null>(null);
  const iframeRef = useRef<HTMLIFrameElement>(null);

  const handlePlay = (track: Track) => {
    setPlaying(track.id);
    setActiveTrack(track);
  };

  const handleStop = () => {
    setPlaying(null);
    setActiveTrack(null);
  };

  const currentTrack = TRACKS.find((t) => t.id === playing);

  return (
    <div className="page-enter" data-testid="page-music">
      <div className="page-pad">

        {/* Hero */}
        <div
          className="hero-banner shimmer"
          style={{
            marginBottom: "1.1rem",
            background: "linear-gradient(135deg, rgba(253,187,45,0.12) 0%, rgba(26,42,108,0.75) 60%, rgba(178,31,31,0.4) 100%)",
          }}
        >
          <div className="hero-title">🎵 Music Lounge</div>
          <p className="hero-subtitle">
            Lo-fi, Chill, Sufi & Desi beats — your vibe, your soundtrack
          </p>
        </div>

        {/* Disc Player */}
        <div
          className="glass-card"
          style={{ padding: "1.75rem 1rem", marginBottom: "1.1rem", textAlign: "center" }}
        >
          {/* Disc */}
          <div style={{ position: "relative", display: "inline-block", marginBottom: "1.1rem" }}>
            <div
              className={`music-disc ${playing ? "playing" : ""}`}
              style={currentTrack ? {
                background: `conic-gradient(from 0deg, ${currentTrack.color}, #b21f1f, #fdbb2d, #b21f1f, ${currentTrack.color})`,
              } : {}}
            >
              <div className="music-disc-inner">
                {playing ? "🎵" : "🎶"}
              </div>
            </div>
            {/* Needle */}
            {playing && (
              <div
                style={{
                  position: "absolute",
                  top: "-8px",
                  right: "-16px",
                  width: "3px",
                  height: "60px",
                  background: "linear-gradient(to bottom, #fdbb2d, rgba(253,187,45,0.3))",
                  borderRadius: "9999px",
                  transformOrigin: "top center",
                  transform: "rotate(25deg)",
                  boxShadow: "0 0 8px rgba(253,187,45,0.4)",
                }}
              />
            )}
          </div>

          {/* Now playing info */}
          {activeTrack ? (
            <div>
              <div
                style={{
                  fontWeight: 700,
                  fontSize: "1.05rem",
                  color: "#fff",
                  marginBottom: "0.2rem",
                  letterSpacing: "-0.01em",
                }}
              >
                {activeTrack.title}
              </div>
              <div style={{ fontSize: "0.8rem", color: "rgba(255,255,255,0.5)", marginBottom: "0.25rem" }}>
                {activeTrack.artist}
              </div>
              <div
                className="badge badge-gold"
                style={{ display: "inline-flex", marginBottom: "1rem" }}
              >
                {activeTrack.genre}
              </div>
              <br />
              <button
                onClick={handleStop}
                data-testid="btn-stop"
                style={{
                  padding: "0.55rem 1.75rem",
                  borderRadius: "9999px",
                  background: "rgba(178,31,31,0.35)",
                  border: "1px solid rgba(178,31,31,0.5)",
                  color: "#fca5a5",
                  fontSize: "0.85rem",
                  fontWeight: 600,
                  cursor: "pointer",
                  fontFamily: "'Poppins', sans-serif",
                  transition: "all 0.2s",
                  backdropFilter: "blur(10px)",
                }}
              >
                ⏸ Stop
              </button>
            </div>
          ) : (
            <div style={{ fontSize: "0.88rem", color: "rgba(255,255,255,0.4)", fontStyle: "italic" }}>
              Select a track below to start playing
            </div>
          )}
        </div>

        {/* Track List */}
        <div className="section-header">
          <div className="section-title"><span>Tracks</span></div>
          <div style={{ fontSize: "0.72rem", color: "rgba(255,255,255,0.35)" }}>
            {TRACKS.length} available
          </div>
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: "0.6rem" }}>
          {TRACKS.map((track, idx) => {
            const isPlaying = playing === track.id;
            return (
              <div
                key={track.id}
                className={`track-row ${isPlaying ? "playing" : ""}`}
                onClick={() => isPlaying ? handleStop() : handlePlay(track)}
                data-testid={`track-${track.id}`}
                role="button"
                tabIndex={0}
                onKeyDown={(e) => e.key === "Enter" && (isPlaying ? handleStop() : handlePlay(track))}
              >
                {/* Track number / play indicator */}
                <div
                  style={{
                    width: 40, height: 40,
                    borderRadius: "50%",
                    background: isPlaying
                      ? `linear-gradient(135deg, ${track.color}, #fdbb2d)`
                      : `rgba(255,255,255,0.07)`,
                    border: `1px solid ${isPlaying ? "transparent" : "rgba(255,255,255,0.1)"}`,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    flexShrink: 0,
                    transition: "all 0.25s",
                    boxShadow: isPlaying ? `0 4px 16px ${track.color}55` : "none",
                  }}
                >
                  {isPlaying ? (
                    <svg width="13" height="13" viewBox="0 0 24 24" fill="white">
                      <path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z" />
                    </svg>
                  ) : (
                    <span style={{ fontSize: "0.75rem", color: "rgba(255,255,255,0.4)", fontWeight: 700 }}>
                      {String(idx + 1).padStart(2, "0")}
                    </span>
                  )}
                </div>

                {/* Info */}
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div
                    style={{
                      fontSize: "0.875rem",
                      fontWeight: 600,
                      color: isPlaying ? "#fdbb2d" : "#fff",
                      overflow: "hidden",
                      textOverflow: "ellipsis",
                      whiteSpace: "nowrap",
                      transition: "color 0.2s",
                    }}
                  >
                    {track.title}
                  </div>
                  <div style={{ fontSize: "0.7rem", color: "rgba(255,255,255,0.42)", marginTop: "1px" }}>
                    {track.artist}
                  </div>
                </div>

                {/* Genre badge */}
                <div className="badge badge-gold" style={{ flexShrink: 0 }}>
                  {track.genre}
                </div>
              </div>
            );
          })}
        </div>

        {/* Hidden audio iframe */}
        {activeTrack && (
          <iframe
            ref={iframeRef}
            src={`https://www.youtube.com/embed/${activeTrack.youtubeId}?autoplay=1&rel=0&modestbranding=1`}
            title="Music player"
            allow="autoplay; encrypted-media"
            style={{ display: "none" }}
            aria-hidden="true"
          />
        )}

        <div
          className="glass-card"
          style={{ padding: "1rem", marginTop: "1.25rem", textAlign: "center", borderColor: "rgba(253,187,45,0.2)" }}
        >
          <div style={{ fontSize: "0.8rem", color: "rgba(255,255,255,0.5)", lineHeight: 1.6 }}>
            🎵 Expand the library — add tracks to{" "}
            <code
              style={{
                background: "rgba(253,187,45,0.12)",
                color: "#fdbb2d",
                padding: "0.1rem 0.4rem",
                borderRadius: "0.3rem",
                fontSize: "0.72rem",
                fontFamily: "monospace",
              }}
            >
              modules/music/
            </code>
          </div>
        </div>
      </div>
    </div>
  );
}
