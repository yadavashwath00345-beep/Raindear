import { useState, useMemo } from "react";

type QuoteCategory = "motivational" | "love" | "life" | "wisdom" | "hindi" | "islamic" | "success" | "nature" | "friendship" | "spiritual";

interface Quote {
  text: string;
  author: string;
  category: QuoteCategory;
}

const CATEGORIES: { id: QuoteCategory; label: string; color: string; bg: string }[] = [
  { id: "motivational", label: "💪 Motivational", color: "#fdbb2d", bg: "rgba(253,187,45,0.12)" },
  { id: "love",         label: "❤️ Love",          color: "#f87171", bg: "rgba(248,113,113,0.12)" },
  { id: "life",         label: "🌱 Life",           color: "#4ade80", bg: "rgba(74,222,128,0.12)" },
  { id: "wisdom",       label: "🧠 Wisdom",         color: "#a78bfa", bg: "rgba(167,139,250,0.12)" },
  { id: "hindi",        label: "🇮🇳 Hindi",         color: "#fb923c", bg: "rgba(251,146,60,0.12)" },
  { id: "islamic",      label: "☪️ Islamic",        color: "#34d399", bg: "rgba(52,211,153,0.12)" },
  { id: "success",      label: "🏆 Success",        color: "#fbbf24", bg: "rgba(251,191,36,0.12)" },
  { id: "nature",       label: "🌿 Nature",         color: "#86efac", bg: "rgba(134,239,172,0.12)" },
  { id: "friendship",   label: "🤝 Friendship",     color: "#93c5fd", bg: "rgba(147,197,253,0.12)" },
  { id: "spiritual",    label: "🕉️ Spiritual",      color: "#f9a8d4", bg: "rgba(249,168,212,0.12)" },
];

const ALL_QUOTES: Quote[] = [
  // MOTIVATIONAL
  { text: "The secret of getting ahead is getting started.", author: "Mark Twain", category: "motivational" },
  { text: "It always seems impossible until it's done.", author: "Nelson Mandela", category: "motivational" },
  { text: "Don't watch the clock; do what it does. Keep going.", author: "Sam Levenson", category: "motivational" },
  { text: "Push yourself, because no one else is going to do it for you.", author: "Unknown", category: "motivational" },
  { text: "Great things never come from comfort zones.", author: "Unknown", category: "motivational" },
  { text: "Dream it. Wish it. Do it.", author: "Unknown", category: "motivational" },
  { text: "Success doesn't just find you. You have to go out and get it.", author: "Unknown", category: "motivational" },
  { text: "The harder you work for something, the greater you'll feel when you achieve it.", author: "Unknown", category: "motivational" },
  { text: "Dream bigger. Do bigger.", author: "Unknown", category: "motivational" },
  { text: "Don't stop when you're tired. Stop when you're done.", author: "Unknown", category: "motivational" },
  { text: "Wake up with determination. Go to bed with satisfaction.", author: "Unknown", category: "motivational" },
  { text: "Do something today that your future self will thank you for.", author: "Sean Patrick Flanery", category: "motivational" },
  { text: "Little things make big days.", author: "Unknown", category: "motivational" },
  { text: "It's going to be hard, but hard is not impossible.", author: "Unknown", category: "motivational" },
  { text: "Don't wait for opportunity. Create it.", author: "Unknown", category: "motivational" },
  { text: "Sometimes we're tested not to show our weaknesses, but to discover our strengths.", author: "Unknown", category: "motivational" },
  { text: "The key to success is to focus on goals, not obstacles.", author: "Unknown", category: "motivational" },
  { text: "Dream it. Believe it. Build it.", author: "Unknown", category: "motivational" },
  { text: "You are braver than you believe, stronger than you seem.", author: "A.A. Milne", category: "motivational" },
  { text: "Act as if what you do makes a difference. It does.", author: "William James", category: "motivational" },
  { text: "Believe you can and you're halfway there.", author: "Theodore Roosevelt", category: "motivational" },
  { text: "Start where you are. Use what you have. Do what you can.", author: "Arthur Ashe", category: "motivational" },
  { text: "You miss 100% of the shots you don't take.", author: "Wayne Gretzky", category: "motivational" },
  { text: "The only way to do great work is to love what you do.", author: "Steve Jobs", category: "motivational" },
  { text: "In the middle of every difficulty lies opportunity.", author: "Albert Einstein", category: "motivational" },
  { text: "It does not matter how slowly you go as long as you do not stop.", author: "Confucius", category: "motivational" },
  { text: "Everything you've ever wanted is on the other side of fear.", author: "George Addair", category: "motivational" },
  { text: "Hardships often prepare ordinary people for an extraordinary destiny.", author: "C.S. Lewis", category: "motivational" },
  { text: "Courage is one step ahead of fear.", author: "Coleman Young", category: "motivational" },
  { text: "Be the change that you wish to see in the world.", author: "Mahatma Gandhi", category: "motivational" },
  { text: "Difficulties in life are intended to make us better, not bitter.", author: "Dan Reeves", category: "motivational" },
  { text: "Don't count the days, make the days count.", author: "Muhammad Ali", category: "motivational" },
  { text: "Strive for progress, not perfection.", author: "Unknown", category: "motivational" },
  { text: "Success is not how high you have climbed, but how you make a positive difference.", author: "Roy T. Bennett", category: "motivational" },
  { text: "Either you run the day, or the day runs you.", author: "Jim Rohn", category: "motivational" },
  { text: "I am not a product of my circumstances. I am a product of my decisions.", author: "Stephen Covey", category: "motivational" },
  // LOVE
  { text: "The best thing to hold onto in life is each other.", author: "Audrey Hepburn", category: "love" },
  { text: "Where there is love there is life.", author: "Mahatma Gandhi", category: "love" },
  { text: "You are my today and all of my tomorrows.", author: "Leo Christopher", category: "love" },
  { text: "Love is not about how many days, months, or years you have been together. It's all about how much you love each other every single day.", author: "Unknown", category: "love" },
  { text: "In all the world, there is no heart for me like yours.", author: "Maya Angelou", category: "love" },
  { text: "You know you're in love when you can't fall asleep because reality is finally better than your dreams.", author: "Dr. Seuss", category: "love" },
  { text: "I love you not only for what you are, but for what I am when I am with you.", author: "Roy Croft", category: "love" },
  { text: "To love and be loved is to feel the sun from both sides.", author: "David Viscott", category: "love" },
  { text: "Love does not consist of gazing at each other, but in looking outward together in the same direction.", author: "Antoine de Saint-Exupéry", category: "love" },
  { text: "A successful marriage requires falling in love many times, always with the same person.", author: "Mignon McLaughlin", category: "love" },
  { text: "The heart wants what it wants — or else it does not care.", author: "Emily Dickinson", category: "love" },
  { text: "If I know what love is, it is because of you.", author: "Hermann Hesse", category: "love" },
  { text: "Love is an untamed force. When we try to control it, it destroys us.", author: "Paulo Coelho", category: "love" },
  { text: "Love is composed of a single soul inhabiting two bodies.", author: "Aristotle", category: "love" },
  { text: "There is only one happiness in this life, to love and be loved.", author: "George Sand", category: "love" },
  // LIFE
  { text: "Life is what happens when you're busy making other plans.", author: "John Lennon", category: "life" },
  { text: "In three words I can sum up everything I've learned about life: it goes on.", author: "Robert Frost", category: "life" },
  { text: "Life is either a daring adventure or nothing at all.", author: "Helen Keller", category: "life" },
  { text: "Life is not measured by the number of breaths we take, but by the moments that take our breath away.", author: "Maya Angelou", category: "life" },
  { text: "The purpose of our lives is to be happy.", author: "Dalai Lama", category: "life" },
  { text: "Get busy living or get busy dying.", author: "Stephen King", category: "life" },
  { text: "You only live once, but if you do it right, once is enough.", author: "Mae West", category: "life" },
  { text: "Many of life's failures are people who did not realize how close they were to success when they gave up.", author: "Thomas Edison", category: "life" },
  { text: "You have brains in your head. You have feet in your shoes. You can steer yourself any direction you choose.", author: "Dr. Seuss", category: "life" },
  { text: "If you want to live a happy life, tie it to a goal, not to people or things.", author: "Albert Einstein", category: "life" },
  { text: "Never let the fear of striking out keep you from playing the game.", author: "Babe Ruth", category: "life" },
  { text: "Life is short, and it is here to be lived.", author: "Kate Winslet", category: "life" },
  { text: "The way I see it, if you want the rainbow, you gotta put up with the rain.", author: "Dolly Parton", category: "life" },
  { text: "Do not go where the path may lead, go instead where there is no path and leave a trail.", author: "Ralph Waldo Emerson", category: "life" },
  { text: "Life is not a problem to be solved, but a reality to be experienced.", author: "Søren Kierkegaard", category: "life" },
  // WISDOM
  { text: "The only true wisdom is in knowing you know nothing.", author: "Socrates", category: "wisdom" },
  { text: "Yesterday I was clever, so I wanted to change the world. Today I am wise, so I am changing myself.", author: "Rumi", category: "wisdom" },
  { text: "The fool doth think he is wise, but the wise man knows himself to be a fool.", author: "Shakespeare", category: "wisdom" },
  { text: "Wonder is the beginning of wisdom.", author: "Socrates", category: "wisdom" },
  { text: "Knowing yourself is the beginning of all wisdom.", author: "Aristotle", category: "wisdom" },
  { text: "A wise man can learn more from a foolish question than a fool can learn from a wise answer.", author: "Bruce Lee", category: "wisdom" },
  { text: "The measure of intelligence is the ability to change.", author: "Albert Einstein", category: "wisdom" },
  { text: "It is not that I'm so smart. But I stay with the questions much longer.", author: "Albert Einstein", category: "wisdom" },
  { text: "Patience is bitter, but its fruit is sweet.", author: "Aristotle", category: "wisdom" },
  { text: "To acquire knowledge, one must study; but to acquire wisdom, one must observe.", author: "Marilyn vos Savant", category: "wisdom" },
  { text: "The wise man does not lay up his own treasures. The more he gives to others, the more he has.", author: "Laozi", category: "wisdom" },
  { text: "A man who dares to waste one hour of time has not discovered the value of life.", author: "Charles Darwin", category: "wisdom" },
  { text: "Wisdom is not a product of schooling but of the lifelong attempt to acquire it.", author: "Albert Einstein", category: "wisdom" },
  { text: "Think before you speak. Read before you think.", author: "Fran Lebowitz", category: "wisdom" },
  { text: "The journey of a thousand miles begins with one step.", author: "Lao Tzu", category: "wisdom" },
  // HINDI
  { text: "Khud ko badlo, duniya khud badal jaayegi.", author: "Mahatma Gandhi", category: "hindi" },
  { text: "Haar ke baad hi jeena sikhta hai insaan.", author: "Unknown", category: "hindi" },
  { text: "Zindagi mein kuch bhi mushkil nahi, bas bas ek kadam aage badhao.", author: "Unknown", category: "hindi" },
  { text: "Waqt badalta hai, insaan nahi. Insaan sirf bada hota hai ya chhota.", author: "Unknown", category: "hindi" },
  { text: "Jo girte hain, uthte hain. Jo rote hain, hanste hain. Yahi zindagi hai.", author: "Unknown", category: "hindi" },
  { text: "Mushkilon se ghabhrana nahi, mushkilon ko hi apna andaaz banana hai.", author: "Unknown", category: "hindi" },
  { text: "Sapne woh nahi jo neend mein aayein, sapne woh hain jo neend na aane dein.", author: "A.P.J. Abdul Kalam", category: "hindi" },
  { text: "Kal ki chinta mat karo, aaj ka kaam karo.", author: "Unknown", category: "hindi" },
  { text: "Zindagi badi honi chahiye, lambi nahi.", author: "Unknown", category: "hindi" },
  { text: "Haar maan lena aasaan hai, jeet ke liye ladna padta hai.", author: "Unknown", category: "hindi" },
  { text: "Bhaagya woh nahi jo haath pe likha ho, bhaagya woh hai jo apne haath se likha ho.", author: "Unknown", category: "hindi" },
  { text: "Jo toot ke bhi nahi jhuka, woh ek din zaroor jita.", author: "Unknown", category: "hindi" },
  { text: "Apni himmat se bado, doosron ki meherbani se nahi.", author: "Unknown", category: "hindi" },
  { text: "Rasta khud banaana padta hai, raaste milte nahi.", author: "Unknown", category: "hindi" },
  { text: "Aaj ka din kal ka kal se behtar hai.", author: "Unknown", category: "hindi" },
  // ISLAMIC
  { text: "Verily, with hardship comes ease.", author: "Quran 94:5", category: "islamic" },
  { text: "And He found you lost and guided you.", author: "Quran 93:7", category: "islamic" },
  { text: "Allah does not burden a soul beyond that it can bear.", author: "Quran 2:286", category: "islamic" },
  { text: "Be in this world as though you were a stranger or a traveler.", author: "Prophet Muhammad ﷺ", category: "islamic" },
  { text: "The strong man is not the one who can wrestle, but the one who controls himself when angry.", author: "Prophet Muhammad ﷺ", category: "islamic" },
  { text: "Do not lose hope, nor be sad.", author: "Quran 3:139", category: "islamic" },
  { text: "Indeed, Allah is with the patient.", author: "Quran 2:153", category: "islamic" },
  { text: "Speak good or remain silent.", author: "Prophet Muhammad ﷺ", category: "islamic" },
  { text: "Make things easy and do not make them difficult.", author: "Prophet Muhammad ﷺ", category: "islamic" },
  { text: "Wealth is not in having many possessions, but wealth is in having contentment of the soul.", author: "Prophet Muhammad ﷺ", category: "islamic" },
  { text: "The best among you are those who have the best manners and character.", author: "Prophet Muhammad ﷺ", category: "islamic" },
  { text: "Whoever believes in Allah and the Last Day, let him speak good or keep silent.", author: "Prophet Muhammad ﷺ", category: "islamic" },
  { text: "Put your trust in Allah, surely Allah loves those who put their trust.", author: "Quran 3:159", category: "islamic" },
  { text: "Remember Me; I will remember you.", author: "Quran 2:152", category: "islamic" },
  { text: "For indeed, with hardship will be ease.", author: "Quran 94:6", category: "islamic" },
  // SUCCESS
  { text: "Success usually comes to those who are too busy to be looking for it.", author: "Henry David Thoreau", category: "success" },
  { text: "The secret of success is to do the common thing uncommonly well.", author: "John D. Rockefeller", category: "success" },
  { text: "I find that the harder I work, the more luck I seem to have.", author: "Thomas Jefferson", category: "success" },
  { text: "Success is not the key to happiness. Happiness is the key to success.", author: "Albert Schweitzer", category: "success" },
  { text: "The difference between a successful person and others is not a lack of strength, but a lack of will.", author: "Vince Lombardi", category: "success" },
  { text: "Success is walking from failure to failure with no loss of enthusiasm.", author: "Winston Churchill", category: "success" },
  { text: "Opportunities don't happen, you create them.", author: "Chris Grosser", category: "success" },
  { text: "Don't be afraid to give up the good to go for the great.", author: "John D. Rockefeller", category: "success" },
  { text: "I owe my success to having listened respectfully to the very best advice, and then going away and doing the exact opposite.", author: "G.K. Chesterton", category: "success" },
  { text: "If you are not willing to risk the usual, you will have to settle for the ordinary.", author: "Jim Rohn", category: "success" },
  { text: "Success is liking yourself, liking what you do, and liking how you do it.", author: "Maya Angelou", category: "success" },
  { text: "The road to success and the road to failure are almost exactly the same.", author: "Colin R. Davis", category: "success" },
  { text: "Try not to become a man of success. Rather become a man of value.", author: "Albert Einstein", category: "success" },
  { text: "Would you like me to give you a formula for success? It's quite simple, really: double your rate of failure.", author: "Thomas J. Watson", category: "success" },
  { text: "There are no secrets to success. It is the result of preparation, hard work, and learning from failure.", author: "Colin Powell", category: "success" },
  // NATURE
  { text: "In every walk with nature, one receives far more than he seeks.", author: "John Muir", category: "nature" },
  { text: "The earth has music for those who listen.", author: "William Shakespeare", category: "nature" },
  { text: "Nature always wears the colors of the spirit.", author: "Ralph Waldo Emerson", category: "nature" },
  { text: "Look deep into nature, and then you will understand everything better.", author: "Albert Einstein", category: "nature" },
  { text: "Adopt the pace of nature: her secret is patience.", author: "Ralph Waldo Emerson", category: "nature" },
  { text: "The clearest way into the Universe is through a forest wilderness.", author: "John Muir", category: "nature" },
  { text: "Nature is not a place to visit. It is home.", author: "Gary Snyder", category: "nature" },
  { text: "Heaven is under our feet as well as over our heads.", author: "Henry David Thoreau", category: "nature" },
  { text: "Not all those who wander are lost.", author: "J.R.R. Tolkien", category: "nature" },
  { text: "The mountains are calling and I must go.", author: "John Muir", category: "nature" },
  { text: "There is no wifi in the forest, but I promise you will find a better connection.", author: "Unknown", category: "nature" },
  { text: "Go where you feel most alive.", author: "Unknown", category: "nature" },
  { text: "Of all the paths you take in life, make sure a few of them are dirt.", author: "John Muir", category: "nature" },
  { text: "The sea, once it casts its spell, holds one in its net of wonder forever.", author: "Jacques Cousteau", category: "nature" },
  { text: "Keep close to Nature's heart, and break clear away, once in awhile.", author: "John Muir", category: "nature" },
  // FRIENDSHIP
  { text: "A real friend is one who walks in when the rest of the world walks out.", author: "Walter Winchell", category: "friendship" },
  { text: "Friendship is the only cement that will ever hold the world together.", author: "Woodrow Wilson", category: "friendship" },
  { text: "A good friend knows all your stories. A best friend helped you write them.", author: "Unknown", category: "friendship" },
  { text: "Friends are the family you choose.", author: "Jess C. Scott", category: "friendship" },
  { text: "True friendship comes when the silence between two people is comfortable.", author: "David Tyson", category: "friendship" },
  { text: "A friend is someone who gives you total freedom to be yourself.", author: "Jim Morrison", category: "friendship" },
  { text: "Friendship is born at that moment when one person says to another, 'What! You too? I thought I was the only one.'", author: "C.S. Lewis", category: "friendship" },
  { text: "There is nothing on this earth more to be prized than true friendship.", author: "Thomas Aquinas", category: "friendship" },
  { text: "One loyal friend is worth ten thousand relatives.", author: "Euripides", category: "friendship" },
  { text: "The most beautiful discovery true friends make is that they can grow separately without growing apart.", author: "Elisabeth Foley", category: "friendship" },
  { text: "A single rose can be my garden; a single friend, my world.", author: "Leo Buscaglia", category: "friendship" },
  { text: "Friendship is the inexpressible comfort of feeling safe with a person.", author: "George Eliot", category: "friendship" },
  { text: "In the end, we will remember not the words of our enemies, but the silence of our friends.", author: "Martin Luther King Jr.", category: "friendship" },
  { text: "A friend is one that knows you as you are, understands where you have been, accepts what you have become.", author: "Shakespeare", category: "friendship" },
  { text: "Don't walk behind me; I may not lead. Don't walk in front of me; I may not follow. Just walk beside me and be my friend.", author: "Albert Camus", category: "friendship" },
  // SPIRITUAL
  { text: "You are not a drop in the ocean. You are the entire ocean in a drop.", author: "Rumi", category: "spiritual" },
  { text: "The soul becomes dyed with the color of its thoughts.", author: "Marcus Aurelius", category: "spiritual" },
  { text: "Silence is the language of God; all else is poor translation.", author: "Rumi", category: "spiritual" },
  { text: "What you seek is seeking you.", author: "Rumi", category: "spiritual" },
  { text: "Your task is not to seek for love, but merely to seek and find all the barriers within yourself that you have built against it.", author: "Rumi", category: "spiritual" },
  { text: "Yesterday I was clever, so I wanted to change the world. Today I am wise, so I am changing myself.", author: "Rumi", category: "spiritual" },
  { text: "The quieter you become, the more you are able to hear.", author: "Rumi", category: "spiritual" },
  { text: "Be grateful for what you already have while you pursue your goals.", author: "Roy T. Bennett", category: "spiritual" },
  { text: "The present moment is the only moment available to us, and it is the door to all moments.", author: "Thich Nhat Hanh", category: "spiritual" },
  { text: "Peace comes from within. Do not seek it without.", author: "Gautama Buddha", category: "spiritual" },
  { text: "Do not dwell in the past, do not dream of the future, concentrate the mind on the present moment.", author: "Gautama Buddha", category: "spiritual" },
  { text: "The mind is everything. What you think you become.", author: "Gautama Buddha", category: "spiritual" },
  { text: "In the middle of difficulty lies opportunity.", author: "Albert Einstein", category: "spiritual" },
  { text: "When you realize nothing is lacking, the whole world belongs to you.", author: "Lao Tzu", category: "spiritual" },
  { text: "Knowing others is wisdom, knowing yourself is enlightenment.", author: "Lao Tzu", category: "spiritual" },
];

function getDayOfYear(): number {
  const now = new Date();
  const start = new Date(now.getFullYear(), 0, 0);
  const diff = now.getTime() - start.getTime();
  const oneDay = 1000 * 60 * 60 * 24;
  return Math.floor(diff / oneDay);
}

function getQuoteOfDay(quotes: Quote[]): Quote {
  if (quotes.length === 0) return ALL_QUOTES[getDayOfYear() % ALL_QUOTES.length];
  return quotes[getDayOfYear() % quotes.length];
}

function QuoteCard({
  quote,
  color,
  bg,
  isMain = false,
}: {
  quote: Quote;
  color: string;
  bg: string;
  isMain?: boolean;
}) {
  const [copied, setCopied] = useState(false);
  const [liked, setLiked] = useState(false);

  const handleCopy = () => {
    navigator.clipboard?.writeText(`"${quote.text}"\n— ${quote.author}`).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div
      className={`glass-card shimmer ${isMain ? "" : ""}`}
      style={{
        padding: isMain ? "1.5rem" : "1rem 1rem 0.75rem",
        borderLeft: `3px solid ${color}`,
        background: bg,
        position: "relative",
        overflow: "hidden",
      }}
    >
      {/* Big quote mark */}
      <div
        style={{
          position: "absolute",
          top: isMain ? "-8px" : "-4px",
          left: isMain ? "1rem" : "0.75rem",
          fontFamily: "Georgia, serif",
          fontSize: isMain ? "5rem" : "3.5rem",
          color: `${color}22`,
          lineHeight: 1,
          pointerEvents: "none",
          userSelect: "none",
        }}
      >
        "
      </div>

      <p
        style={{
          fontSize: isMain ? "1rem" : "0.875rem",
          color: "rgba(255,255,255,0.9)",
          lineHeight: 1.75,
          fontStyle: "italic",
          paddingTop: isMain ? "1rem" : "0.65rem",
          fontFamily: isMain ? "'Dancing Script', cursive" : "'Poppins', sans-serif",
          fontWeight: isMain ? 600 : 400,
          margin: 0,
        }}
      >
        {quote.text}
      </p>

      <div
        style={{
          marginTop: "0.65rem",
          fontSize: "0.72rem",
          color: color,
          fontWeight: 700,
          opacity: 0.85,
          letterSpacing: "0.02em",
        }}
      >
        — {quote.author}
      </div>

      <div style={{ display: "flex", gap: "0.45rem", marginTop: "0.75rem", justifyContent: "flex-end" }}>
        <button
          onClick={() => setLiked((l) => !l)}
          style={{
            background: liked ? "rgba(239,68,68,0.18)" : "rgba(255,255,255,0.06)",
            border: `1px solid ${liked ? "rgba(239,68,68,0.4)" : "rgba(255,255,255,0.1)"}`,
            borderRadius: "0.4rem",
            padding: "0.22rem 0.65rem",
            fontSize: "0.68rem",
            color: liked ? "#f87171" : "rgba(255,255,255,0.4)",
            cursor: "pointer",
            transition: "all 0.2s",
            fontFamily: "'Poppins', sans-serif",
            fontWeight: 600,
          }}
        >
          {liked ? "❤️" : "♡"} Like
        </button>
        <button
          className={`copy-btn ${copied ? "copied" : ""}`}
          onClick={handleCopy}
          style={{ position: "static" }}
        >
          {copied ? "✓ Copied" : "Share"}
        </button>
      </div>
    </div>
  );
}

export default function Quotes() {
  const [activeCategory, setActiveCategory] = useState<QuoteCategory | "all">("all");

  const catQuotes = useMemo(() => {
    if (activeCategory === "all") return ALL_QUOTES;
    return ALL_QUOTES.filter((q) => q.category === activeCategory);
  }, [activeCategory]);

  const todayQuote = useMemo(() => getQuoteOfDay(
    activeCategory === "all" ? ALL_QUOTES : catQuotes
  ), [activeCategory, catQuotes]);

  const catObj = CATEGORIES.find((c) => c.id === activeCategory);
  const todayColor = catObj?.color ?? "#fdbb2d";
  const todayBg    = catObj?.bg    ?? "rgba(253,187,45,0.08)";

  const otherQuotes = catQuotes.filter((q) => q !== todayQuote).slice(0, 20);

  const now = new Date();
  const dateStr = now.toLocaleDateString("en-IN", { weekday: "long", year: "numeric", month: "long", day: "numeric" });

  return (
    <div className="page-enter" data-testid="page-quotes">
      <div className="page-pad">

        {/* Hero */}
        <div
          className="hero-banner shimmer"
          style={{
            marginBottom: "1.1rem",
            background: "linear-gradient(135deg, rgba(26,42,108,0.8) 0%, rgba(124,58,237,0.45) 60%, rgba(253,187,45,0.1) 100%)",
          }}
        >
          <div
            style={{
              fontSize: "0.65rem",
              color: "rgba(255,255,255,0.45)",
              letterSpacing: "0.1em",
              textTransform: "uppercase",
              fontWeight: 600,
              marginBottom: "0.25rem",
            }}
          >
            📅 {dateStr}
          </div>
          <div className="hero-title" style={{ fontFamily: "'Poppins', sans-serif", fontSize: "1.35rem", fontWeight: 800 }}>
            ✨ Quote of the Day
          </div>
          <p className="hero-subtitle">
            {ALL_QUOTES.length}+ quotes across 10 moods — a new one every day
          </p>
        </div>

        {/* TODAY'S FEATURED QUOTE */}
        <div style={{ marginBottom: "1.1rem" }}>
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: "0.5rem",
              marginBottom: "0.65rem",
            }}
          >
            <div
              style={{
                width: 4, height: 20,
                borderRadius: 2,
                background: todayColor,
                flexShrink: 0,
              }}
            />
            <div style={{ fontSize: "0.85rem", fontWeight: 700, color: "#fff" }}>
              Today's Quote
            </div>
            <div
              className="badge"
              style={{ background: `${todayColor}22`, color: todayColor, border: `1px solid ${todayColor}44` }}
            >
              Daily Pick
            </div>
          </div>
          <QuoteCard quote={todayQuote} color={todayColor} bg={todayBg} isMain />
        </div>

        {/* Category Filter */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: "0.5rem",
            marginBottom: "0.85rem",
            fontSize: "0.8rem",
            fontWeight: 700,
            color: "rgba(255,255,255,0.6)",
          }}
        >
          Browse by mood:
        </div>
        <div className="cat-tabs" style={{ marginBottom: "1rem" }}>
          <button
            className={`cat-tab ${activeCategory === "all" ? "active" : ""}`}
            onClick={() => setActiveCategory("all")}
          >
            🌟 All
          </button>
          {CATEGORIES.map((cat) => (
            <button
              key={cat.id}
              className={`cat-tab ${activeCategory === cat.id ? "active" : ""}`}
              onClick={() => setActiveCategory(cat.id as QuoteCategory)}
              style={activeCategory === cat.id ? {
                background: cat.bg,
                borderColor: `${cat.color}55`,
                color: cat.color,
              } : {}}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* More Quotes from category */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "0.75rem" }}>
          <div style={{ fontSize: "0.85rem", fontWeight: 700, color: "#fff" }}>
            More Quotes
          </div>
          <div style={{ fontSize: "0.7rem", color: "rgba(255,255,255,0.38)" }}>
            {catQuotes.length} total
          </div>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: "0.65rem" }}>
          {otherQuotes.map((q, i) => {
            const cat = CATEGORIES.find((c) => c.id === q.category);
            return (
              <QuoteCard
                key={`${q.author}-${i}`}
                quote={q}
                color={cat?.color ?? "#fdbb2d"}
                bg={cat?.bg ?? "rgba(253,187,45,0.07)"}
              />
            );
          })}
        </div>

        {/* Footer count */}
        <div
          className="glass-card"
          style={{
            padding: "1rem",
            marginTop: "1.25rem",
            textAlign: "center",
            borderColor: "rgba(167,139,250,0.25)",
          }}
        >
          <div style={{ fontSize: "1.1rem", fontWeight: 800, color: "#a78bfa" }}>
            {ALL_QUOTES.length}+
          </div>
          <div style={{ fontSize: "0.78rem", color: "rgba(255,255,255,0.5)", marginTop: "0.2rem" }}>
            Handpicked quotes across {CATEGORIES.length} moods • Updates daily
          </div>
        </div>
      </div>
    </div>
  );
}
