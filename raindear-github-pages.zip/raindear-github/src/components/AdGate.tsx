import { useState, useEffect, useRef } from "react";
import { useLanguage } from "@/contexts/LanguageContext";

const AD_KEY = "raindear_ad_last_seen";
const AD_INTERVAL_MS = 24 * 60 * 60 * 1000; // 24 hours
const AD_COUNTDOWN_SECS = 5; // must watch for 5 seconds before skipping

function shouldShowAd(): boolean {
  try {
    const last = localStorage.getItem(AD_KEY);
    if (!last) return true;
    return Date.now() - Number(last) > AD_INTERVAL_MS;
  } catch {
    return true;
  }
}

function markAdSeen() {
  try {
    localStorage.setItem(AD_KEY, String(Date.now()));
  } catch {}
}

interface AdGateProps {
  onDone: () => void;
}

export default function AdGate({ onDone }: AdGateProps) {
  const [show, setShow] = useState(false);
  const [countdown, setCountdown] = useState(AD_COUNTDOWN_SECS);
  const [canSkip, setCanSkip] = useState(false);
  const [adPhase, setAdPhase] = useState<"loading" | "playing" | "done">("loading");
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const { lang } = useLanguage();

  useEffect(() => {
    if (shouldShowAd()) {
      setShow(true);
      // Brief "loading" phase for realism
      setTimeout(() => setAdPhase("playing"), 800);
    } else {
      onDone();
    }
  }, [onDone]);

  useEffect(() => {
    if (adPhase !== "playing") return;
    timerRef.current = setInterval(() => {
      setCountdown((c) => {
        if (c <= 1) {
          clearInterval(timerRef.current!);
          setCanSkip(true);
          return 0;
        }
        return c - 1;
      });
    }, 1000);
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [adPhase]);

  const handleSkip = () => {
    if (!canSkip) return;
    markAdSeen();
    setAdPhase("done");
    setTimeout(onDone, 350);
  };

  if (!show) return null;

  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        zIndex: 9999,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        background: "rgba(8,12,32,0.97)",
        backdropFilter: "blur(32px)",
        WebkitBackdropFilter: "blur(32px)",
        padding: "1rem",
      }}
    >
      {/* Top bar */}
      <div
        style={{
          position: "absolute",
          top: "env(safe-area-inset-top, 12px)",
          left: 0, right: 0,
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          padding: "0.75rem 1.1rem",
        }}
      >
        <div
          style={{
            fontSize: "0.62rem",
            fontWeight: 700,
            color: "rgba(255,255,255,0.3)",
            letterSpacing: "0.1em",
            textTransform: "uppercase",
          }}
        >
          {lang === "hi" ? "विज्ञापन" : "Advertisement"}
        </div>

        {/* Skip button / countdown */}
        <button
          onClick={handleSkip}
          disabled={!canSkip}
          style={{
            display: "flex",
            alignItems: "center",
            gap: "0.4rem",
            padding: "0.4rem 0.9rem",
            borderRadius: "9999px",
            border: canSkip
              ? "1.5px solid rgba(253,187,45,0.7)"
              : "1.5px solid rgba(255,255,255,0.18)",
            background: canSkip
              ? "rgba(253,187,45,0.18)"
              : "rgba(255,255,255,0.06)",
            color: canSkip ? "#fdbb2d" : "rgba(255,255,255,0.45)",
            fontSize: "0.78rem",
            fontWeight: 700,
            fontFamily: "'Poppins', sans-serif",
            cursor: canSkip ? "pointer" : "default",
            transition: "all 0.3s ease",
            letterSpacing: "0.02em",
            touchAction: "manipulation",
            boxShadow: canSkip ? "0 0 16px rgba(253,187,45,0.25)" : "none",
          }}
        >
          {canSkip ? (
            <>
              {lang === "hi" ? "छोड़ें" : "Skip"}
              <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor">
                <path d="M6 18l8.5-6L6 6v12zm2-8.14L11.03 12 8 14.14V9.86zM16 6h2v12h-2z"/>
              </svg>
            </>
          ) : (
            <>
              {lang === "hi" ? "छोड़ें" : "Skip"} {countdown}s
            </>
          )}
        </button>
      </div>

      {/* AD CONTENT — replace this block with your real ad unit after AdSense/AdMob approval */}
      <div
        style={{
          width: "100%",
          maxWidth: 420,
          borderRadius: "1.25rem",
          overflow: "hidden",
          border: "1px solid rgba(255,255,255,0.1)",
          boxShadow: "0 24px 80px rgba(0,0,0,0.7)",
        }}
      >
        {adPhase === "loading" ? (
          <div
            style={{
              aspectRatio: "16/9",
              background: "rgba(255,255,255,0.04)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <div
              style={{
                width: 36, height: 36,
                border: "3px solid rgba(253,187,45,0.25)",
                borderTopColor: "#fdbb2d",
                borderRadius: "50%",
                animation: "spin 0.8s linear infinite",
              }}
            />
          </div>
        ) : (
          /* 
            ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
            REPLACE THIS ENTIRE DIV WITH YOUR AD UNIT
            e.g. a Google IMA SDK video ad, or your 
            sponsor's video embedded here.

            For now it shows a beautiful branded 
            interstitial promoting the app itself.
            ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
          */
          <div
            style={{
              aspectRatio: "16/9",
              background: "linear-gradient(135deg, #0d1b4b 0%, #6b1a1a 50%, #e06c1a 100%)",
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              padding: "1.5rem",
              textAlign: "center",
              position: "relative",
              overflow: "hidden",
            }}
          >
            {/* Animated background glow */}
            <div
              style={{
                position: "absolute",
                inset: 0,
                background: "radial-gradient(circle at 70% 30%, rgba(253,187,45,0.2) 0%, transparent 60%)",
                pointerEvents: "none",
              }}
            />

            <div
              style={{
                fontSize: "3rem",
                marginBottom: "0.75rem",
                filter: "drop-shadow(0 4px 16px rgba(253,187,45,0.5))",
                position: "relative",
                zIndex: 1,
                animation: "pulse 2s ease-in-out infinite",
              }}
            >
              🌅
            </div>

            <div
              style={{
                fontFamily: "'Dancing Script', cursive",
                fontSize: "clamp(1.4rem, 5vw, 2rem)",
                fontWeight: 700,
                background: "linear-gradient(135deg, #fdbb2d 0%, #fff 60%)",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
                backgroundClip: "text",
                marginBottom: "0.4rem",
                position: "relative",
                zIndex: 1,
              }}
            >
              Raindear
            </div>

            <div
              style={{
                fontSize: "clamp(0.72rem, 2.5vw, 0.85rem)",
                color: "rgba(255,255,255,0.75)",
                lineHeight: 1.5,
                maxWidth: 280,
                position: "relative",
                zIndex: 1,
              }}
            >
              {lang === "hi"
                ? "शायरी, संगीत, तथ्य और प्रकृति — आपकी अपनी दुनिया"
                : "Shayari · Music · Facts · Nature — Your premium world"}
            </div>
          </div>
        )}

        {/* Progress bar */}
        <div
          style={{
            height: 3,
            background: "rgba(255,255,255,0.08)",
            position: "relative",
          }}
        >
          <div
            style={{
              position: "absolute",
              left: 0, top: 0, bottom: 0,
              background: "linear-gradient(90deg, #fdbb2d, #b21f1f)",
              width: canSkip
                ? "100%"
                : `${((AD_COUNTDOWN_SECS - countdown) / AD_COUNTDOWN_SECS) * 100}%`,
              transition: "width 1s linear",
              borderRadius: "0 3px 3px 0",
            }}
          />
        </div>
      </div>

      {/* Bottom message */}
      <div
        style={{
          marginTop: "1.25rem",
          fontSize: "0.7rem",
          color: "rgba(255,255,255,0.28)",
          textAlign: "center",
          lineHeight: 1.55,
        }}
      >
        {lang === "hi"
          ? "यह विज्ञापन Raindear को मुफ्त रखने में मदद करता है"
          : "This ad helps keep Raindear free for everyone"}
        <br />
        <span style={{ color: "rgba(255,255,255,0.15)", fontSize: "0.62rem" }}>
          {lang === "hi" ? "दिन में एक बार • कोई खाता नहीं" : "Once per day • No account needed"}
        </span>
      </div>

      <style>{`
        @keyframes spin { to { transform: rotate(360deg); } }
        @keyframes pulse { 0%,100% { transform: scale(1); } 50% { transform: scale(1.08); } }
      `}</style>
    </div>
  );
}
