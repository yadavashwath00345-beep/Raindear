import { useHaptics } from "@/hooks/useHaptics";
import { useLanguage } from "@/contexts/LanguageContext";

interface HeaderProps {
  musicOn: boolean;
  vibrationOn: boolean;
  onToggleMusic: () => void;
  onToggleVibration: () => void;
  showInstall?: boolean;
  onInstall?: () => void;
  onSearch?: () => void;
}

export default function Header({
  musicOn,
  vibrationOn,
  onToggleMusic,
  onToggleVibration,
  showInstall,
  onInstall,
  onSearch,
}: HeaderProps) {
  const { tap } = useHaptics(vibrationOn);
  const { lang, setLang, t } = useLanguage();

  return (
    <header
      data-testid="app-header"
      className="app-header"
      style={{
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        background: "rgba(0,0,0,0.3)",
        backdropFilter: "blur(24px)",
        WebkitBackdropFilter: "blur(24px)",
        borderBottom: "1px solid rgba(255,255,255,0.08)",
        position: "sticky",
        top: 0,
        zIndex: 100,
        gap: "0.5rem",
        flexShrink: 0,
      }}
    >
      {/* Brand Logo */}
      <div style={{ display: "flex", alignItems: "center", gap: "0.5rem", flexShrink: 0 }}>
        <div
          style={{
            width: 36, height: 36,
            borderRadius: "50%",
            background: "linear-gradient(135deg, #fdbb2d 0%, #e06c1a 50%, #b21f1f 100%)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            boxShadow: "0 4px 18px rgba(253,187,45,0.45), 0 2px 6px rgba(0,0,0,0.3)",
            flexShrink: 0,
          }}
        >
          <svg width="16" height="16" viewBox="0 0 24 24" fill="white">
            <path d="M12 3v10.55c-.59-.34-1.27-.55-2-.55-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4V7h4V3h-6z" />
          </svg>
        </div>
        <div>
          <div
            style={{
              fontFamily: "'Dancing Script', cursive",
              fontSize: "1.35rem",
              fontWeight: 700,
              lineHeight: 1,
              background: "linear-gradient(135deg, #fdbb2d 0%, #fff 60%)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
              backgroundClip: "text",
            }}
          >
            Raindear
          </div>
          <div
            style={{
              fontSize: "0.5rem",
              color: "rgba(255,255,255,0.38)",
              letterSpacing: "0.12em",
              textTransform: "uppercase",
              fontWeight: 600,
              lineHeight: 1,
              marginTop: "1px",
            }}
          >
            {t("tagline")}
          </div>
        </div>
      </div>

      {/* Right Controls */}
      <div style={{ display: "flex", alignItems: "center", gap: "0.45rem" }}>

        {/* Search Button */}
        <button
          onClick={() => { tap(); onSearch?.(); }}
          data-testid="btn-search"
          aria-label="Search"
          style={{
            background: "rgba(255,255,255,0.08)",
            border: "1px solid rgba(255,255,255,0.13)",
            borderRadius: "0.5rem",
            width: 32, height: 32,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            cursor: "pointer",
            transition: "all 0.2s",
            flexShrink: 0,
          }}
        >
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.65)" strokeWidth="2.2" strokeLinecap="round">
            <circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" />
          </svg>
        </button>

        {/* Language Toggle */}
        <button
          onClick={() => { tap(); setLang(lang === "en" ? "hi" : "en"); }}
          data-testid="btn-lang"
          aria-label="Toggle language"
          style={{
            background: "rgba(255,255,255,0.08)",
            border: "1px solid rgba(255,255,255,0.13)",
            borderRadius: "0.5rem",
            padding: "0 0.55rem",
            height: 32,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            cursor: "pointer",
            transition: "all 0.2s",
            flexShrink: 0,
            fontFamily: "'Poppins', sans-serif",
            fontSize: "0.68rem",
            fontWeight: 700,
            color: "#fdbb2d",
            letterSpacing: "0.04em",
            gap: "0.2rem",
          }}
        >
          <span style={{ fontSize: "0.75rem" }}>{lang === "en" ? "🇮🇳" : "🇬🇧"}</span>
          {lang === "en" ? "हि" : "EN"}
        </button>

        {/* PWA Install Button */}
        {showInstall && (
          <button
            className="install-btn"
            onClick={() => { tap(); onInstall?.(); }}
            data-testid="btn-install"
            aria-label="Install Raindear app"
            style={{ padding: "0 0.7rem", height: 32 }}
          >
            <svg width="11" height="11" viewBox="0 0 24 24" fill="currentColor">
              <path d="M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z"/>
            </svg>
            {t("install")}
          </button>
        )}

        {/* Music Toggle */}
        <div style={{ display: "flex", alignItems: "center", gap: "0.25rem" }}>
          <svg
            width="12" height="12" viewBox="0 0 24 24"
            fill={musicOn ? "#fdbb2d" : "rgba(255,255,255,0.3)"}
            style={{ transition: "fill 0.25s", flexShrink: 0 }}
          >
            <path d="M12 3v10.55c-.59-.34-1.27-.55-2-.55-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4V7h4V3h-6z" />
          </svg>
          <button
            className={`toggle-switch ${musicOn ? "on" : ""}`}
            onClick={() => { tap(); onToggleMusic(); }}
            data-testid="toggle-music"
            aria-label={`Music ${musicOn ? "on" : "off"}`}
            style={{ width: 38, height: 22 }}
          >
            <div className="toggle-knob" style={{ top: 3, width: 14, height: 14 }} />
          </button>
        </div>

        {/* Vibration Toggle */}
        <div style={{ display: "flex", alignItems: "center", gap: "0.25rem" }}>
          <svg
            width="12" height="12" viewBox="0 0 24 24"
            fill={vibrationOn ? "#fdbb2d" : "rgba(255,255,255,0.3)"}
            style={{ transition: "fill 0.25s", flexShrink: 0 }}
          >
            <path d="M0 15h2V9H0v6zm3 2h2V7H3v10zm19-8v6h2V9h-2zm-3 8h2V7h-2v10zM16.5 3h-9C6.67 3 6 3.67 6 4.5v15c0 .83.67 1.5 1.5 1.5h9c.83 0 1.5-.67 1.5-1.5v-15c0-.83-.67-1.5-1.5-1.5zM16 19H8V5h8v14z" />
          </svg>
          <button
            className={`toggle-switch ${vibrationOn ? "on" : ""}`}
            onClick={() => { onToggleVibration(); }}
            data-testid="toggle-vibration"
            aria-label={`Vibration ${vibrationOn ? "on" : "off"}`}
            style={{ width: 38, height: 22 }}
          >
            <div className="toggle-knob" style={{ top: 3, width: 14, height: 14 }} />
          </button>
        </div>
      </div>
    </header>
  );
}
