import { useState, useMemo, useRef, useEffect } from "react";
import { useLanguage } from "@/contexts/LanguageContext";

interface SearchResult {
  type: "shayari" | "quote" | "fact" | "game";
  text: string;
  meta: string;
  category?: string;
}

// Flat searchable data — pulled from all pages
const SEARCH_DATA: SearchResult[] = [
  // SHAYARI
  { type: "shayari", text: "Teri aankhon mein kho jaata hoon main, Har khwaab mein tujhe hi paata hoon main...", meta: "Love Shayari", category: "love" },
  { type: "shayari", text: "Mohabbat ki zubaan hoti hai khamoshi, Tujhse milke mili hai dil ko khushi...", meta: "Love Shayari", category: "love" },
  { type: "shayari", text: "Teri muskaan pe fida hoon main, Tere pyaar ka diwana hoon main...", meta: "Love Shayari", category: "love" },
  { type: "shayari", text: "Har raat tere sapne aate hain, Har subah tere khayaal jaate hain...", meta: "Love Shayari", category: "love" },
  { type: "shayari", text: "Dard mein bhi muskurana seekh liya humne, Zindagi ne bahut kuch sikhaya hai humein...", meta: "Sad Shayari", category: "sad" },
  { type: "shayari", text: "Teri yaad aati hai jab bhi raat hoti hai, Dil pe teri tasveer bann jaati hai...", meta: "Sad Shayari", category: "sad" },
  { type: "shayari", text: "Khamoshi meri zubaan ban gayi hai, Dard hi ab meri pehchaan ban gayi hai...", meta: "Sad Shayari", category: "sad" },
  { type: "shayari", text: "Girte hain shehsawar hi maidan-e-jung mein, Woh tifl kya girenge jo ghutno ke bal chale...", meta: "Motivational Shayari", category: "motivational" },
  { type: "shayari", text: "Mushkilon se nahi ghabhraate hain hum, Mushkilon ko hi apna andaaz banaate hain...", meta: "Motivational Shayari", category: "motivational" },
  { type: "shayari", text: "Sapne woh nahi jo neend mein aayein, Sapne woh hain jo neend na aane dein...", meta: "Motivational Shayari", category: "motivational" },
  { type: "shayari", text: "Ghar wale keh rahe hain padh lo, Hum keh rahe hain — kal se pakka!", meta: "Funny Shayari", category: "funny" },
  { type: "shayari", text: "Dil ne kaha diet karo, Pet ne kaha — acha joke tha!", meta: "Funny Shayari", category: "funny" },
  { type: "shayari", text: "Dost woh hote hain jo dard baat lein, Jo khushiyon mein saath haan mein maan lein...", meta: "Friendship Shayari", category: "friendship" },
  { type: "shayari", text: "Yaari mein koi hisab nahi hota, Sach ki dosti mein koi andaaz nahi hota...", meta: "Friendship Shayari", category: "friendship" },
  { type: "shayari", text: "Tere jaisa dost milna mushkil hai, Tere bina jeena dil ke liye mushkil hai...", meta: "Friendship Shayari", category: "friendship" },
  // QUOTES
  { type: "quote", text: "The secret of getting ahead is getting started.", meta: "Mark Twain", category: "motivational" },
  { type: "quote", text: "It always seems impossible until it's done.", meta: "Nelson Mandela", category: "motivational" },
  { type: "quote", text: "Dream it. Wish it. Do it.", meta: "Unknown", category: "motivational" },
  { type: "quote", text: "The best thing to hold onto in life is each other.", meta: "Audrey Hepburn", category: "love" },
  { type: "quote", text: "Where there is love there is life.", meta: "Mahatma Gandhi", category: "love" },
  { type: "quote", text: "In every walk with nature, one receives far more than he seeks.", meta: "John Muir", category: "nature" },
  { type: "quote", text: "The mountains are calling and I must go.", meta: "John Muir", category: "nature" },
  { type: "quote", text: "Life is what happens when you're busy making other plans.", meta: "John Lennon", category: "life" },
  { type: "quote", text: "In three words I can sum up everything I've learned about life: it goes on.", meta: "Robert Frost", category: "life" },
  { type: "quote", text: "The only true wisdom is in knowing you know nothing.", meta: "Socrates", category: "wisdom" },
  { type: "quote", text: "Yesterday I was clever, so I wanted to change the world. Today I am wise, so I am changing myself.", meta: "Rumi", category: "wisdom" },
  { type: "quote", text: "Khud ko badlo, duniya khud badal jaayegi.", meta: "Mahatma Gandhi", category: "hindi" },
  { type: "quote", text: "Sapne woh nahi jo neend mein aayein, sapne woh hain jo neend na aane dein.", meta: "A.P.J. Abdul Kalam", category: "hindi" },
  { type: "quote", text: "Verily, with hardship comes ease.", meta: "Quran 94:5", category: "islamic" },
  { type: "quote", text: "Allah does not burden a soul beyond that it can bear.", meta: "Quran 2:286", category: "islamic" },
  { type: "quote", text: "Be in this world as though you were a stranger or a traveler.", meta: "Prophet Muhammad ﷺ", category: "islamic" },
  { type: "quote", text: "Success usually comes to those who are too busy to be looking for it.", meta: "Henry David Thoreau", category: "success" },
  { type: "quote", text: "You are not a drop in the ocean. You are the entire ocean in a drop.", meta: "Rumi", category: "spiritual" },
  { type: "quote", text: "What you seek is seeking you.", meta: "Rumi", category: "spiritual" },
  { type: "quote", text: "A real friend is one who walks in when the rest of the world walks out.", meta: "Walter Winchell", category: "friendship" },
  { type: "quote", text: "Peace comes from within. Do not seek it without.", meta: "Gautama Buddha", category: "spiritual" },
  // FACTS
  { type: "fact", text: "Lightning strikes Earth about 100 times every second.", meta: "Science — NASA" },
  { type: "fact", text: "India invented the number system (0–9). Without it, modern math wouldn't exist.", meta: "India — History" },
  { type: "fact", text: "Chess was invented in India around the 6th century AD, called 'Chaturanga'.", meta: "India — History" },
  { type: "fact", text: "One million Earths could fit inside the Sun.", meta: "Space — NASA" },
  { type: "fact", text: "Sharks are older than trees — they've existed for over 450 million years.", meta: "Animals — Paleontology" },
  { type: "fact", text: "Octopuses have 3 hearts, blue blood, and 9 brains.", meta: "Animals — Marine Biology" },
  { type: "fact", text: "The first computer bug was a literal bug — a moth found inside a Harvard computer in 1947.", meta: "Tech — Computing History" },
  { type: "fact", text: "Your heart beats about 100,000 times a day — 37 million times a year.", meta: "Human Body" },
  { type: "fact", text: "Honey never spoils — 3000-year-old honey found in Egyptian tombs was still edible.", meta: "Food — Archaeology" },
  { type: "fact", text: "The ocean covers 71% of Earth's surface but over 80% remains unexplored.", meta: "Ocean — NOAA" },
  { type: "fact", text: "Cleopatra lived closer to the Moon landing than to the building of the Great Pyramid.", meta: "History" },
  { type: "fact", text: "Dolphins have names for each other and call out to specific individuals.", meta: "Animals — Marine Biology" },
  { type: "fact", text: "Hot water can freeze faster than cold water under certain conditions (Mpemba Effect).", meta: "Weird — Physics" },
  { type: "fact", text: "India is the largest democracy in the world with over 900 million eligible voters.", meta: "India — ECI" },
  { type: "fact", text: "Bananas are curved because they grow toward the Sun.", meta: "Food — Botany" },
  { type: "fact", text: "You share 60% of your DNA with a banana.", meta: "Human Body — Genetics" },
  { type: "fact", text: "The human brain generates about 23 watts of power — enough to light a dim bulb.", meta: "Human Body — Neuroscience" },
  { type: "fact", text: "Ants can lift 50 times their own body weight.", meta: "Animals — Entomology" },
  { type: "fact", text: "Salt was once so valuable it was used as currency — the word 'salary' comes from salt.", meta: "Food — Etymology" },
  { type: "fact", text: "Coffee is the second most traded commodity in the world after oil.", meta: "Food — Trade Stats" },
];

const TYPE_ICON: Record<SearchResult["type"], string> = {
  shayari: "✍️",
  quote:   "✨",
  fact:    "💡",
  game:    "🎮",
};

const TYPE_COLOR: Record<SearchResult["type"], string> = {
  shayari: "#b21f1f",
  quote:   "#a78bfa",
  fact:    "#fdbb2d",
  game:    "#4ade80",
};

const TYPE_LABEL: Record<SearchResult["type"], { en: string; hi: string }> = {
  shayari: { en: "Shayari",  hi: "शायरी" },
  quote:   { en: "Quote",    hi: "विचार" },
  fact:    { en: "Fact",     hi: "तथ्य" },
  game:    { en: "Game",     hi: "खेल" },
};

interface SearchOverlayProps {
  open: boolean;
  onClose: () => void;
}

export default function SearchOverlay({ open, onClose }: SearchOverlayProps) {
  const { lang, t } = useLanguage();
  const [query, setQuery] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (open) {
      setTimeout(() => inputRef.current?.focus(), 120);
    } else {
      setQuery("");
    }
  }, [open]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    if (open) window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  const results = useMemo<SearchResult[]>(() => {
    const q = query.trim().toLowerCase();
    if (q.length < 2) return [];
    return SEARCH_DATA.filter(
      (item) =>
        item.text.toLowerCase().includes(q) ||
        item.meta.toLowerCase().includes(q) ||
        (item.category ?? "").toLowerCase().includes(q)
    ).slice(0, 30);
  }, [query]);

  if (!open) return null;

  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        zIndex: 500,
        display: "flex",
        flexDirection: "column",
        background: "rgba(10,14,40,0.97)",
        backdropFilter: "blur(24px)",
        WebkitBackdropFilter: "blur(24px)",
      }}
      data-testid="search-overlay"
    >
      {/* Search Header */}
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: "0.75rem",
          padding: "0.9rem 1rem",
          borderBottom: "1px solid rgba(255,255,255,0.08)",
          background: "rgba(0,0,0,0.3)",
        }}
      >
        {/* Search icon */}
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.4)" strokeWidth="2" strokeLinecap="round">
          <circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" />
        </svg>

        <input
          ref={inputRef}
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder={t("searchPlaceholder")}
          data-testid="search-input"
          style={{
            flex: 1,
            background: "transparent",
            border: "none",
            outline: "none",
            color: "#fff",
            fontSize: "1rem",
            fontFamily: "'Poppins', sans-serif",
            fontWeight: 500,
          }}
        />

        {query && (
          <button
            onClick={() => setQuery("")}
            style={{
              background: "rgba(255,255,255,0.1)",
              border: "none",
              borderRadius: "50%",
              width: 22, height: 22,
              color: "rgba(255,255,255,0.6)",
              cursor: "pointer",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontSize: "0.7rem",
              fontWeight: 700,
              flexShrink: 0,
            }}
          >
            ✕
          </button>
        )}

        <button
          onClick={onClose}
          style={{
            background: "rgba(255,255,255,0.08)",
            border: "1px solid rgba(255,255,255,0.12)",
            borderRadius: "0.45rem",
            padding: "0.3rem 0.75rem",
            color: "rgba(255,255,255,0.6)",
            fontSize: "0.78rem",
            fontWeight: 600,
            cursor: "pointer",
            fontFamily: "'Poppins', sans-serif",
            flexShrink: 0,
            transition: "all 0.2s",
          }}
        >
          {lang === "hi" ? "बंद करें" : "Cancel"}
        </button>
      </div>

      {/* Results Area */}
      <div style={{ flex: 1, overflowY: "auto", padding: "0.75rem 1rem" }}>
        {query.length >= 2 && results.length === 0 && (
          <div style={{ textAlign: "center", paddingTop: "3rem" }}>
            <div style={{ fontSize: "2.5rem", marginBottom: "0.75rem" }}>🔍</div>
            <div style={{ fontSize: "1rem", fontWeight: 700, color: "#fff", marginBottom: "0.35rem" }}>
              {t("noResults")}
            </div>
            <div style={{ fontSize: "0.8rem", color: "rgba(255,255,255,0.4)" }}>
              {t("noResultsHint")}
            </div>
          </div>
        )}

        {query.length >= 2 && results.length > 0 && (
          <>
            <div
              style={{
                fontSize: "0.72rem",
                color: "rgba(255,255,255,0.38)",
                marginBottom: "0.75rem",
                fontWeight: 500,
              }}
            >
              {t("resultsFor")} "{query}" — {results.length} {lang === "hi" ? "परिणाम" : "results"}
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: "0.55rem" }}>
              {results.map((item, i) => (
                <SearchResultCard key={i} item={item} query={query} lang={lang} />
              ))}
            </div>
          </>
        )}

        {query.length < 2 && (
          <div style={{ paddingTop: "2rem" }}>
            <div
              style={{
                fontSize: "0.75rem",
                color: "rgba(255,255,255,0.35)",
                textAlign: "center",
                marginBottom: "1.5rem",
              }}
            >
              {lang === "hi" ? "खोजने के लिए टाइप करें" : "Start typing to search"}
            </div>

            {/* Quick categories */}
            <div style={{ marginBottom: "0.65rem" }}>
              <div style={{ fontSize: "0.72rem", color: "rgba(255,255,255,0.35)", marginBottom: "0.5rem", fontWeight: 600, letterSpacing: "0.06em", textTransform: "uppercase" }}>
                {lang === "hi" ? "तेज़ खोज" : "Quick Search"}
              </div>
              <div style={{ display: "flex", flexWrap: "wrap", gap: "0.45rem" }}>
                {["love", "sad", "dost", "zindagi", "rumi", "gandhi", "india", "space", "nature", "Quran", "ocean", "funny"].map((tag) => (
                  <button
                    key={tag}
                    onClick={() => setQuery(tag)}
                    style={{
                      padding: "0.3rem 0.85rem",
                      borderRadius: "9999px",
                      background: "rgba(255,255,255,0.07)",
                      border: "1px solid rgba(255,255,255,0.12)",
                      color: "rgba(255,255,255,0.65)",
                      fontSize: "0.78rem",
                      cursor: "pointer",
                      fontFamily: "'Poppins', sans-serif",
                      transition: "all 0.2s",
                    }}
                  >
                    {tag}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function highlight(text: string, query: string): string {
  // Returns plain string for now (HTML highlight would need dangerouslySetInnerHTML)
  return text;
}

function SearchResultCard({ item, query, lang }: { item: SearchResult; query: string; lang: string }) {
  const [copied, setCopied] = useState(false);
  const color = TYPE_COLOR[item.type];
  const label = TYPE_LABEL[item.type][lang === "hi" ? "hi" : "en"];

  const handleCopy = () => {
    navigator.clipboard?.writeText(`${item.text}\n— ${item.meta}`).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Highlight matching text
  const q = query.toLowerCase();
  const idx = item.text.toLowerCase().indexOf(q);
  let displayText;
  if (idx >= 0) {
    const before = item.text.slice(0, idx);
    const match  = item.text.slice(idx, idx + query.length);
    const after  = item.text.slice(idx + query.length);
    displayText = (
      <>
        {before}
        <mark style={{ background: `${color}40`, color: color, borderRadius: "2px" }}>{match}</mark>
        {after}
      </>
    );
  } else {
    displayText = item.text;
  }

  return (
    <div
      style={{
        background: "rgba(255,255,255,0.045)",
        border: "1px solid rgba(255,255,255,0.08)",
        borderLeft: `3px solid ${color}`,
        borderRadius: "0.75rem",
        padding: "0.9rem 1rem",
        display: "flex",
        gap: "0.75rem",
        alignItems: "flex-start",
        backdropFilter: "blur(12px)",
      }}
    >
      <div style={{ fontSize: "1.3rem", flexShrink: 0, lineHeight: 1.2 }}>{TYPE_ICON[item.type]}</div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div
          style={{
            display: "inline-flex",
            alignItems: "center",
            padding: "0.1rem 0.55rem",
            borderRadius: "9999px",
            background: `${color}18`,
            border: `1px solid ${color}33`,
            color: color,
            fontSize: "0.6rem",
            fontWeight: 700,
            letterSpacing: "0.06em",
            textTransform: "uppercase",
            marginBottom: "0.45rem",
          }}
        >
          {label}
        </div>
        <p
          style={{
            fontSize: "0.85rem",
            color: "rgba(255,255,255,0.88)",
            lineHeight: 1.6,
            margin: 0,
            fontFamily: item.type === "shayari" ? "'Dancing Script', cursive" : "'Poppins', sans-serif",
            fontWeight: item.type === "shayari" ? 600 : 400,
          }}
        >
          {displayText}
        </p>
        <div style={{ fontSize: "0.68rem", color: "rgba(255,255,255,0.38)", marginTop: "0.35rem" }}>
          — {item.meta}
        </div>
      </div>
      <button
        onClick={handleCopy}
        style={{
          background: copied ? "rgba(34,197,94,0.15)" : "rgba(255,255,255,0.06)",
          border: `1px solid ${copied ? "rgba(34,197,94,0.35)" : "rgba(255,255,255,0.1)"}`,
          borderRadius: "0.4rem",
          padding: "0.25rem 0.6rem",
          fontSize: "0.62rem",
          color: copied ? "#4ade80" : "rgba(255,255,255,0.4)",
          cursor: "pointer",
          fontWeight: 600,
          fontFamily: "'Poppins', sans-serif",
          flexShrink: 0,
          transition: "all 0.2s",
          letterSpacing: "0.04em",
          textTransform: "uppercase",
          alignSelf: "flex-start",
        }}
      >
        {copied ? "✓" : "📋"}
      </button>
    </div>
  );
}
