import { useHaptics } from "@/hooks/useHaptics";
import { useLanguage } from "@/contexts/LanguageContext";
import { type TranslationKeys } from "@/i18n";

export type TabId = "explore" | "nature" | "facts" | "quotes" | "games" | "shayari" | "music";

interface PillNavProps {
  active: TabId;
  onSelect: (tab: TabId) => void;
  vibrationOn: boolean;
}

const TABS: { id: TabId; key: TranslationKeys; icon: string }[] = [
  { id: "explore", key: "explore", icon: "🌅" },
  { id: "nature",  key: "nature",  icon: "🌿" },
  { id: "facts",   key: "facts",   icon: "💡" },
  { id: "quotes",  key: "quotes",  icon: "✨" },
  { id: "games",   key: "games",   icon: "🎮" },
  { id: "shayari", key: "shayari", icon: "✍️" },
  { id: "music",   key: "music",   icon: "🎵" },
];

export default function PillNav({ active, onSelect, vibrationOn }: PillNavProps) {
  const { tap } = useHaptics(vibrationOn);
  const { t } = useLanguage();

  return (
    <nav className="pill-nav" data-testid="pill-nav" aria-label="Main navigation">
      {TABS.map((tab) => (
        <button
          key={tab.id}
          className={`pill-btn ${active === tab.id ? "active" : ""}`}
          onClick={() => { tap(); onSelect(tab.id); }}
          data-testid={`pill-${tab.id}`}
          aria-current={active === tab.id ? "page" : undefined}
        >
          <span style={{ marginRight: "0.35rem" }} aria-hidden="true">{tab.icon}</span>
          {t(tab.key)}
        </button>
      ))}
    </nav>
  );
}
