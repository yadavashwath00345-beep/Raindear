import { useLanguage } from "@/contexts/LanguageContext";

interface AppFooterProps {
  onNavigate: (hash: string) => void;
}

export default function AppFooter({ onNavigate }: AppFooterProps) {
  const { lang } = useLanguage();

  return (
    <footer
      style={{
        borderTop: "1px solid rgba(255,255,255,0.07)",
        padding: "1rem 1.25rem",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        flexWrap: "wrap",
        gap: "0.5rem",
        background: "rgba(0,0,0,0.15)",
        backdropFilter: "blur(12px)",
      }}
    >
      <span
        style={{
          fontSize: "0.68rem",
          color: "rgba(255,255,255,0.28)",
          fontFamily: "'Dancing Script', cursive",
          fontWeight: 600,
        }}
      >
        © 2025 Raindear
      </span>

      <div style={{ display: "flex", gap: "1rem", alignItems: "center" }}>
        <button
          onClick={() => onNavigate("about")}
          style={{
            background: "none",
            border: "none",
            fontSize: "0.7rem",
            color: "rgba(255,255,255,0.42)",
            cursor: "pointer",
            padding: "0.25rem 0",
            fontFamily: "'Poppins', sans-serif",
            transition: "color 0.2s",
            touchAction: "manipulation",
          }}
        >
          {lang === "hi" ? "हमारे बारे में" : "About"}
        </button>
        <span style={{ color: "rgba(255,255,255,0.15)", fontSize: "0.6rem" }}>•</span>
        <button
          onClick={() => onNavigate("privacy")}
          style={{
            background: "none",
            border: "none",
            fontSize: "0.7rem",
            color: "rgba(255,255,255,0.42)",
            cursor: "pointer",
            padding: "0.25rem 0",
            fontFamily: "'Poppins', sans-serif",
            transition: "color 0.2s",
            touchAction: "manipulation",
          }}
        >
          {lang === "hi" ? "गोपनीयता नीति" : "Privacy Policy"}
        </button>
      </div>
    </footer>
  );
}
