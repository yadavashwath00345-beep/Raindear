export default function WaveLayer() {
  return (
    <div className="wave-container" aria-hidden="true">
      <svg
        className="wave-svg"
        viewBox="0 0 1440 100"
        preserveAspectRatio="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M0,50 C120,90 240,10 360,50 C480,90 600,10 720,50 C840,90 960,10 1080,50 C1200,90 1320,10 1440,50 L1440,100 L0,100 Z"
          fill="rgba(255,255,255,0.045)"
        />
      </svg>
      <svg
        className="wave-svg-2"
        viewBox="0 0 1440 80"
        preserveAspectRatio="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M0,40 C180,80 360,0 540,40 C720,80 900,0 1080,40 C1260,80 1380,20 1440,40 L1440,80 L0,80 Z"
          fill="rgba(253,187,45,0.04)"
        />
      </svg>
    </div>
  );
}
