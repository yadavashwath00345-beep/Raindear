import { useState } from "react";

interface VideoFacadeProps {
  videoId: string;
  title?: string;
  showTitle?: boolean;
  badge?: string;
}

export default function VideoFacade({ videoId, title, showTitle = true, badge }: VideoFacadeProps) {
  const [loaded, setLoaded] = useState(false);
  const [imgError, setImgError] = useState(false);

  const thumb = imgError
    ? `https://img.youtube.com/vi/${videoId}/default.jpg`
    : `https://img.youtube.com/vi/${videoId}/mqdefault.jpg`;

  if (loaded) {
    return (
      <div className="video-facade">
        <iframe
          src={`https://www.youtube.com/embed/${videoId}?autoplay=1&rel=0&modestbranding=1`}
          title={title || "YouTube video"}
          allow="autoplay; encrypted-media; fullscreen"
          allowFullScreen
          style={{
            width: "100%",
            height: "100%",
            border: "none",
            position: "absolute",
            inset: 0,
          }}
          loading="lazy"
        />
      </div>
    );
  }

  return (
    <div
      className="video-facade"
      onClick={() => setLoaded(true)}
      data-testid={`video-facade-${videoId}`}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => e.key === "Enter" && setLoaded(true)}
      aria-label={`Play: ${title || "video"}`}
    >
      <img
        src={thumb}
        alt={title || "Video thumbnail"}
        loading="lazy"
        onError={() => setImgError(true)}
        style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }}
      />
      <div className="video-play-btn">
        <div className="play-icon-circle">
          <svg
            width="19"
            height="19"
            viewBox="0 0 24 24"
            fill="white"
            style={{ marginLeft: "2px" }}
          >
            <path d="M8 5v14l11-7z" />
          </svg>
        </div>
      </div>
      {badge && (
        <div style={{ position: "absolute", top: "0.45rem", left: "0.45rem" }}>
          <span className={`badge ${badge === "LIVE" ? "badge-live" : "badge-gold"}`}>
            {badge}
          </span>
        </div>
      )}
      {showTitle && title && (
        <div className="video-title-bar truncate-2">{title}</div>
      )}
    </div>
  );
}
