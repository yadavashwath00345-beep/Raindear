import { useState, useEffect } from "react";

interface Preferences {
  musicOn: boolean;
  vibrationOn: boolean;
}

const STORAGE_KEY = "raindear_prefs";

const defaults: Preferences = {
  musicOn: false,
  vibrationOn: true,
};

function load(): Preferences {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return { ...defaults, ...JSON.parse(raw) };
  } catch {}
  return defaults;
}

function save(prefs: Preferences) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(prefs));
  } catch {}
}

export function usePreferences() {
  const [prefs, setPrefs] = useState<Preferences>(load);

  useEffect(() => {
    save(prefs);
  }, [prefs]);

  const toggleMusic = () =>
    setPrefs((p) => ({ ...p, musicOn: !p.musicOn }));

  const toggleVibration = () =>
    setPrefs((p) => ({ ...p, vibrationOn: !p.vibrationOn }));

  return { prefs, toggleMusic, toggleVibration };
}
