export function useHaptics(enabled: boolean) {
  const vibrate = (pattern: number | number[] = 30) => {
    if (!enabled) return;
    if (typeof navigator !== "undefined" && "vibrate" in navigator) {
      try {
        navigator.vibrate(pattern);
      } catch {}
    }
  };

  const tap = () => vibrate(25);
  const pulse = () => vibrate([30, 50, 30]);
  const success = () => vibrate([20, 30, 60]);

  return { vibrate, tap, pulse, success };
}
